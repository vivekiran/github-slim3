<?php
namespace SlimApp\Model;

use Illuminate\Database\Eloquent\Model;

class Widget extends Model
{

}
