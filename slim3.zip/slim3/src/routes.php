<?php
// Routes
//https://github.com/mrcoco/slim3-eloquent-skeleton

/*$app->get('/[{name}]', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});*/


// Define app routes
$app->get('/jsonresponse', function ($request, $response,$args) {
    $data = array('name' => 'Rob', 'age' => 40);
    return $response->withJson($data, 500);
});


$app->get('/create', function ($request, $response) {
    $widget = new \SlimApp\Model\Widget();
    $widget->serial_number = 123;
    $widget->name = 'My Test Widget';
    $widget->save();
    echo 'Created!';
});

$app->get('/widget-all', function ($request, $response) {
    $widget = \SlimApp\Model\Widget::all();
    return $response->withJson($widget, 200);
});
