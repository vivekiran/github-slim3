<?php

  return [
    'paths' => [
      'migrations' => 'migrations'
    ],
    'migration_base_class' => '\SlimApp\Migration\Migration',
    'environments' => [
      'default_migration_table' => 'phinxlog',
      'default_database' => 'dev',
      'dev' => [
        'adapter' => 'mysql',
        'host' => 'localhost',
        'name' => 'slim3',
        'user' => 'root',
        'pass' => 'root@123#',
        'port' => null
      ]
    ]
  ];
