<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if (!empty($field_id)) {
    $sql = "SELECT f.field_id,fs.fieldset_id,fs.fieldset_name,f.field_label,he.element_name,f.html_element_id,f.prepend_text
    FROM field f
    INNER JOIN fieldset fs ON f.fieldset_id = fs.fieldset_id
    LEFT JOIN html_element he ON f.html_element_id = he.html_element_id";
    $sql .= " WHERE f.field_id='$field_id'";
    $fieldset = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

    $field_label = $fieldset['field_label'];
    $fieldset_id = $fieldset['fieldset_id'];
    $html_element_id = $fieldset['html_element_id'];
    $prepend_text = stripslashes($fieldset['prepend_text']);
?>




<!doctype html>
<html>
    <head>
        <title>Add Field</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script src="dist/bootstrap.min.js"></script>
        <script type="text/javascript">
        $(function () {
            $("[1data-toggle='tooltip']").tooltip();
        });
    </script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <h2>Add/Update Field</h2>
                <form name="validateForm" id="validateForm" action="processAddUpdateField.php" class="form-horizontal" method="post" role="form">
                    <input type="hidden" name="field_id" id="field_id" value="<?php echo $field_id ?>" />

                <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Field Label</label>
                        <div class="col-sm-9">
                            <input required="required" type="text" name="enter_field_label" class="form-control" id="enter_field_label" value="<?php echo $field_label; ?>" />
                        </div>
                    </div>


                      <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Prepend Text </label>
                        <div class="col-sm-9">
                            <input type="text" name="enter_prepend_text" class="form-control" id="enter_prepend_text" value='<?php echo $prepend_text; ?>' />
                        </div>
                    </div>

                <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select fieldset</label>
                     <div class="col-sm-9">
                    <select name="fieldset_id" id="fieldset_id" required="required" class="form-control">
                        <option value="">--Select fieldset--</option>
                        <?php
                        foreach ($disclosure_platform->fieldset() as $fieldset) {
                            $selectedModule = ($fieldset_id==$fieldset['fieldset_id'] ? "selected='selected'":'');


                            if(!empty($fetchFieldSet)){
                                $selectedModule =  ($fetchFieldSet==$fieldset['fieldset_id'] ? "selected='selected'":'');
                            }


                      echo '<option '.$selectedModule.' value="'.$fieldset['fieldset_id'].'">'.$fieldset['fieldset_name'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>


                  <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select html element</label>
                     <div class="col-sm-9">
                    <select name="html_element_id" id="html_element_id" required="required" class="form-control">
                        <option value="">--Select html element--</option>
                        <?php
                        foreach ($disclosure_platform->html_element() as $html_element) {
                            $selectedHTMLTypeModule = ($html_element_id==$html_element['html_element_id'] ? "selected='selected'":'');
                      echo '<option '.$selectedHTMLTypeModule.' value="'.$html_element['html_element_id'].'">'.$html_element['element_name'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>

                   <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Attributes</label>
                        <div class="col-sm-9" id="fetchAttributes">

                        </div>
                    </div>


                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Select Options</label>
                        <div class="col-sm-9" id="fetchSelectOptions">

                        </div>
                    </div>
                    <h3> List of Validation </h3>
                        <table class="table table-striped">
                          <thead>
                            <tr>
                              <th width="10%">Select</th>
                              <th width="10%">Validation method</th>
                              <th width="40%">Validation Description</th>
                              <th width="30%">Validation Param</th>
                              <th width="10%">Validation Message</th>
                              <th width="5%">Validation Order</th>
                            </tr>
                          </thead>
                          <tbody>
                        <?php
                            foreach ($disclosure_platform->m_validation() as $validation) {
                                $selectedValidationId = $validation['validation_id'];
                                $sqlValid = "SELECT * FROM field_validation WHERE field_id='$field_id' and validation_id='$selectedValidationId'";
                                $sqlValidresult = $connection->query($sqlValid)->fetch(PDO::FETCH_ASSOC);
                            ?>
                            <tr>
                              <td width="10%"><input type="checkbox" name="list_validation[]" value=<?=$validation['validation_id']?> <?php
                              if($validation['validation_id']==$sqlValidresult['validation_id']){

                                echo "checked='checked'";
                              }
                              ?>/></td>
                              <td width="10%" class="clearfix" data-toggle="tooltip" data-placement="top" title=""><?=$validation['validation_method']?></td>
                              <td width="40%"><?=$validation['validation_description']?></td>
                              <td width="30%"><input type="text" name="validationparam[<?=$validation['validation_id']?>]" value='<?=$sqlValidresult['param']?>' /></textarea></td>
                              <td width="10%"><textarea name="validationmessage[<?=$validation['validation_id']?>]"><?=$sqlValidresult['validation_message']?></textarea></td>
                              <td width="5%"><input type="text" name="validationorder[<?=$validation['validation_id']?>]" value="<?=$sqlValidresult['validation_order']?>" /></td>
                            </tr>
                          </tbody>
                          <?php  } ?>
                        </table>





                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-primary">Submit</button>
                             <input type="reset" class="btn btn-default" value="reset" />
                        </div>
                    </div>
                                                            <div class="modal fade" id="edit-controls" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">

                            </div>
                        </div>
                    </div>
                    <input type=""
                </form>

            </div>
        </div>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/angular.js/1.2.16/angular.min.js"></script>
        <script type="text/javascript" src="dist/addField.js"></script>
    </body>
</html>
