<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$form_response = stripslashes($form_response);
$form_response = json_decode($form_response,true);

$form_response_final = json_encode($form_response->fields);

if(!empty($m_feature_controller_ids)){
    $explodeControllerId = explode(",", $m_feature_controller_ids);
    /**
     * Deleting all the controllers first
     * @var [type]
     */
    $m_control_delete_result = $disclosure_platform->m_control()->where("m_control_id",$explodeControllerId);

    $map_feature_delete_sub_control = $disclosure_platform->map_feature_sub_control()->where("m_control_id",$explodeControllerId)->where("m_feature_sub_id",$m_feature_sub_id);

    $updatedControlData = array(
        "deleted_by" => -1,
        "deleted_datentime" => date("Y-m-d H:i:s")
    );
    $m_control_delete_result->update($updatedControlData);

    $updatedControlMapData = array(
        "control_order"=>null,
        "deleted_by" => -1,
        "deleted_datentime" => date("Y-m-d H:i:s")
    );
    $map_feature_delete_sub_control->update($updatedControlMapData);
}

$m_feature_sub = $disclosure_platform->m_feature_sub(array("m_feature_sub_id" => $m_feature_sub_id));
$m_feature_sub->update(array("feature_response" => $form_response_final));


$listOfControllerId = array();
$removedControllerId = array();
$countZeroOrder = 1;
$countClientZeroOrder = 1;
foreach ($form_response->fields as $fieldKey => $fieldValues) {

    $m_control_id = null;
    $map_feature_sub_control_id = null;
    $controller_common_field = null;

    $control_name = $fieldValues->field_element_name;
    $control_type = $fieldValues->field_type;
    $control_label = $fieldValues->label;
    $control_tooltip = $fieldValues->tool_tip;
    $description = $fieldValues->field_options->description;
    $controller_common_field = ($fieldValues->common_field ? 'Y':'N');


    $m_control_result = $disclosure_platform->m_control(array("control_name = ?"=>$control_name))->fetch();

    $m_control_id = $m_control_result['m_control_id'];

    //if($m_control->count()==0){

        $m_control = $disclosure_platform->m_control()->insert_update(
        array("m_control_id"=>$m_control_id),
        array(
            "control_name" => $control_name,
            "control_type" => $control_type,
            "created_by"=> '-1',
            "created_datentime" => date("Y-m-d H:i:s"),
            "activate_by"=> '-1',
            "activated_datentime" => date("Y-m-d H:i:s")
        ),array(
            "control_name" => $control_name,
            "control_type" => $control_type,
            "deleted_by"=> null,
            "deleted_datentime"=>null
        ));


         if(empty($m_control_id))
         $m_control_id = $disclosure_platform->m_control()->insert_id();


        array_push($listOfControllerId, $m_control_id);

         if($control_type=='radio' || $control_type=='dropdown' || $control_type=='checkbox'){

                $m_control_option_result = $disclosure_platform->m_control_option()->where("m_control_id",$m_control_id);
                $updatedControlOptionData = array(
                    "deleted_by" => -1,
                    "deleted_datentime" => date("Y-m-d H:i:s")
                );
                $m_control_option_result->update($updatedControlOptionData);

                foreach ($fieldValues->field_options->options as $key => $value) {
                    $option_checked = null;
                    $option_checked = ($value->checked == 1 ? $value->checked : null);
                    $m_control_option = $disclosure_platform->m_control_option()->insert(
                    array(
                    "m_control_id" => $m_control_id,
                    "option_label" => $value->label,
                    "option_value" => $value->value,
                    "option_checked" => $option_checked,
                    "created_by"=> '-1',
                    "created_datentime" => date("Y-m-d H:i:s"),
                    "activate_by"=> '-1',
                    "activated_datentime" => date("Y-m-d H:i:s")
                    ));
                }

        }

        $map_feature_sub_control_result = $disclosure_platform->map_feature_sub_control(array("m_feature_sub_id = ?"=>$m_feature_sub_id,"m_control_id = ?"=>$m_control_id))->fetch();

        $map_feature_sub_control_id = $map_feature_sub_control_result['map_feature_sub_control_id'];

        $map_feature_sub_control = $disclosure_platform->map_feature_sub_control()->insert_update(
            array("map_feature_sub_control_id"=>$map_feature_sub_control_id),
            array(
                "m_feature_sub_id" => $m_feature_sub_id,
                "m_control_id" => $m_control_id,
                "control_order" => $countZeroOrder,
                "common_control" => $controller_common_field,
                "control_label" => $control_label,
                "control_tooltip" => $control_tooltip,
                "description" => $description,
                "created_by"=> '-1',
                "created_datentime" => date("Y-m-d H:i:s"),
                "activate_by"=> '-1',
                "activated_datentime" => date("Y-m-d H:i:s")
            ),array(
                "m_feature_sub_id" => $m_feature_sub_id,
                "m_control_id" => $m_control_id,
                "control_order" => $countZeroOrder,
                "common_control" => $controller_common_field,
                "control_label" => $control_label,
                "control_tooltip" => $control_tooltip,
                "description" => $description,
                "deleted_by"=> null,
                "deleted_datentime"=>null
            ));


        if(empty($map_feature_sub_control_id))
         $map_feature_sub_control_id = $disclosure_platform->map_feature_sub_control()->insert_id();


            if($controller_common_field=='Y'){

                foreach ($disclosure_platform->client()->where("deleted_datentime",null) as $client){
                        $client_id = null;
                        $client_id = $client['client_id'];

                        if(!empty($map_feature_sub_control_id)){
                                $client_feature_control = $disclosure_platform->client_feature_control()->where("client_id",$client_id)->where("map_feature_sub_control_id = ?",$map_feature_sub_control_id);

                                if($client_feature_control->count()==0){
                                        $m_feature = $disclosure_platform->client_feature_control()->insert(array(
                                        "client_id" => $client_id,
                                        "map_feature_sub_control_id" => $map_feature_sub_control_id,
                                        "control_order" => $countClientZeroOrder,
                                        "created_by"=> '-1',
                                        "created_datentime" => date("Y-m-d H:i:s"),
                                        "activate_by"=> '-1',
                                        "activated_datentime" => date("Y-m-d H:i:s")
                                        ));
                                } else {
                                        $data_results = array(
                                         "control_order" => $countClientZeroOrder,
                                        "deleted_by" => NULL,
                                        "deleted_datentime" => NULL
                                    );
                                    $client_feature_control->update($data_results);
                                }
                        }

                }
                $countClientZeroOrder++;

           } elseif ($controller_common_field=='N') {
               foreach ($disclosure_platform->client()->where("deleted_datentime",null) as $client){
                        $client_id = null;
                        $client_id = $client['client_id'];

                        if(!empty($map_feature_sub_control_id)){
                                $client_feature_control = $disclosure_platform->client_feature_control()->where("client_id",$client_id)->where("map_feature_sub_control_id = ?",$map_feature_sub_control_id);

                                if($client_feature_control->count() > 0) {
                                        $data_results = array(
                                        "control_order" => null,
                                        "deleted_by" => -1,
                                        "deleted_datentime" => date("Y-m-d H:i:s")
                                    );
                                    $client_feature_control->update($data_results);
                                }
                        }

                }
           }


            foreach ($fieldValues->field_validations as $validation_name => $validation_value) {

                    $m_validation = $disclosure_platform->m_validation(array("validation_name" => $validation_name))->fetch();
                    $m_validation_id = $m_validation['m_validation_id'];


                    $map_control_validation_result = $disclosure_platform->map_control_validation()->where("m_control_id",$m_control_id)->where("m_validation_id",$m_validation_id);



                    $set_control_validation_id = null;

                    $set_control_validation_id = $map_control_validation_result[0]['map_control_validation_id'];

                    $map_validation_result = $disclosure_platform->map_validation()->where("map_control_validation_id",$set_control_validation_id)->where("map_feature_sub_control_id",$map_feature_sub_control_id);


                    $set_map_validation_id = null;

                    $set_map_validation_id = $map_validation_result[0]['map_validation_id'];


                    $validation_common_result = $disclosure_platform->validation_common()->where("map_validation_id",$set_map_validation_id);

                    if($validation_value){

                        if($map_control_validation_result->count()==0){
                            $map_control_validation = $disclosure_platform->map_control_validation()->insert(array(
                                "m_control_id" => $m_control_id,
                                "m_validation_id" => $m_validation_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activate_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));
                            $map_control_validation_id = null;
                            $map_control_validation_id = $disclosure_platform->map_control_validation()->insert_id();
                        } elseif ($map_control_validation_result->count()>0) {
                           $dataUpdateMapControlValidation = array(
                                "deleted_by" => null,
                                "deleted_datentime" => null
                            );
                           $map_control_validation_result->update($dataUpdateMapControlValidation);
                        }

                        if(empty($map_control_validation_id)){
                            $map_control_validation_id = $set_control_validation_id;
                        }


                        if($map_validation_result->count()==0){
                             $map_validation = $disclosure_platform->map_validation()->insert(array(
                                "map_feature_sub_control_id" => $map_feature_sub_control_id,
                                "map_control_validation_id" => $map_control_validation_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activate_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));

                             $map_validation_id = null;

                            $map_validation_id = $disclosure_platform->map_validation()->insert_id();
                        } elseif ($map_validation_result->count()>0) {
                           $dataUpdateMapControlValidation = array(
                                "deleted_by" => null,
                                "deleted_datentime" => null
                            );
                           $map_validation_result->update($dataUpdateMapControlValidation);
                        }

                        if(empty($map_validation_id)){
                            $map_validation_id = $set_map_validation_id;
                        }

                        if($validation_common_result->count()==0){
                             $validation_common = $disclosure_platform->validation_common()->insert(array(
                                "map_validation_id" => $map_validation_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activate_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));
                        } elseif ($validation_common_result->count()>0) {
                           $dataUpdateMapControlValidation = array(
                                "deleted_by" => null,
                                "deleted_datentime" => null
                            );
                           $validation_common_result->update($dataUpdateMapControlValidation);
                        }

                    } else {
                            $dataUpdateMapControlValidation = array(
                                "deleted_by" => -1,
                                "deleted_datentime" => date("Y-m-d H:i:s")
                            );
                            $map_control_validation_result->update($dataUpdateMapControlValidation);
                            $validation_common_result->update($dataUpdateMapControlValidation);
                            $map_validation_result->update($dataUpdateMapControlValidation);
                    }

            }

        $countZeroOrder++;


    //}
}

echo json_encode(array(
    'm_feature_id' => $m_feature_id,
    'list_controller_id' => $listOfControllerId
));
