<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if (!empty($page_id)) {
    $sql = "SELECT section_id,page_id, page_name,file_name FROM page ";
    $sql .= "WHERE page_id='$page_id'";
    $page = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

$page_name = $page['page_name'];
$file_name = $page['file_name'];
$section_id = $page['section_id'];
?>




<!doctype html>
<html>
    <head>
        <title>Add Page</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <h2>Add/Update Page</h2>
                <form action="processAddUpdatePage.php" class="form-horizontal" method="post" role="form">
                    <input type="hidden" name="page_id" id="page_id" value="<?php echo $page_id ?>" />

                      <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select section</label>
                     <div class="col-sm-9">
                    <select name="section_id" id="section_id" required="required" class="form-control">
                        <option value="">--Select section--</option>
                        <?php
                        foreach ($disclosure_platform->section() as $section) {
                            $selectedModule = ($section_id==$section['section_id'] ? "selected='selected'":'');

                            if(!empty($fetchSection)){
                                $selectedModule =  ($fetchSection==$section['section_id'] ? "selected='selected'":'');
                            }
                      echo '<option '.$selectedModule.' value="'.$section['section_id'].'">'.$section['section_name'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>

                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Page Name</label>
                        <div class="col-sm-9">
                            <input required="required" type="text" name="enter_page_name" class="form-control" id="enter_page_name" value="<?php echo $page_name; ?>" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter File Name</label>
                        <div class="col-sm-9">
                           <input name="enter_file_name" class="form-control" id="enter_file_name" value="<?php echo $file_name; ?>" />
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>


    </body>
</html>