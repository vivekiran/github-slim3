<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

if(empty($selectFeature) && empty($selectSubFeature)){
  header("location:selectSubFeatureForm.php");
  die();
}



$m_feature_sub = $disclosure_platform->m_feature_sub(array("m_feature_sub_id"=>$selectSubFeature))->fetch();


$sub_feature_name = $m_feature_sub['feature_sub'];

$fields_query = "SELECT c.m_control_id as control_id,c.control_label as label, c.control_type as field_type, c.description, c.control_name as field_element_name, c.control_name as field_element_id,  c.control_name as cid, c.control_tooltip as tool_tip, group_concat(mv.validation_name) as validations,if(a.common_control='Y',1,'') as common_field
    FROM
    m_control c
    INNER JOIN map_feature_sub_control a ON c.m_control_id = a.m_control_id
    INNER JOIN map_feature_sub mfs ON a.m_feature_sub_id = mfs.m_feature_sub_id
    LEFT JOIN map_control_validation mcv ON c.m_control_id = mcv.m_control_id AND mcv.deleted_datentime is NULL
    LEFT JOIN validation_common vc on mcv.map_control_validation_id = vc.map_control_validation_id AND vc.deleted_datentime is NULL
    LEFT JOIN m_validation mv ON mcv.m_validation_id = mv.m_validation_id
    WHERE
    a.m_feature_sub_id ='" . $selectSubFeature . "' AND mfs.m_feature_id = '" . $selectFeature . "' AND c.control_type NOT IN ('button','html', 'securityQuestions') AND c.deleted_datentime is NULL
    GROUP BY
    c.m_control_id ORDER BY control_order ASC";

?>
<!doctype html>
<html>
<head>
  <title>Form Builder</title>
  <meta name="description" content="">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
  <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
      
  <link rel="stylesheet" href="vendor/css/vendor.css" />
  <link rel="stylesheet" href="dist/formbuilder.css" />
  <style>
  * {
    box-sizing: border-box;
  }
      
  body {
    background-color: #444;
    font-family: sans-serif;
  }
      
  .fb-main {
    background-color: #fff;
    border-radius: 5px;
    min-height: 600px;
  }
      
  input[type=text] {
    height: 26px;
    margin-bottom: 3px;
  }
      
  select {
    margin-bottom: 5px;
/*    font-size: 40px;*/
  }
  div.row{
    background-color: #fff;
    border-radius: 5px;
    margin-bottom: 20px
  }
  .loading {
  height:100px;
  width:300px;
  background-color:#FFFFFF;
  margin:0 auto!important;
  margin-top:200px!important;
  -moz-border-radius: 5px;
  border:4px solid #ddd;
}
.spinner {
  background-image:url(dist/images/spinner.png);
  height: 100%;
  position: fixed;
  width: 100%;
  z-index: 1000;
  display:none;
}
.loading_img {
  background-image:url(dist/images/loading.gif) !important;
  background-position: 2px 34px !important;
  background-repeat: no-repeat !important;
  float: left;
  height: 35px;
  margin-left: 16px;
  padding-top: 60px;
  width: 244px;
}
  </style>
</head>
<body>
    <div class="spinner">
        <div class="loading">
            <div class="loading_img">
                <p>Authenticating User, Please wait </p>
            </div>
        </div>
    </div>

    <div class="container">
        <?php require_once 'menu.php'; ?>

        <div class="jumbotron">
            <input type="hidden" name="m_feature_id" id="m_feature_id" value="<?= $selectFeature ?>" />
            <input type="hidden" name="m_feature_sub_id" id="m_feature_sub_id" value="<?= $selectSubFeature ?>" />
            <input type="hidden" name="m_feature_controller_ids" id="m_feature_controller_ids" value="<?= $m_feature_controller_ids ?>" />
            <h2>Sub Feature name: <?= $sub_feature_name ?></h2>
            
            <div class='fb-main'></div>

            <script src="vendor/js/vendor.js"></script>
            <script src="dist/formbuilder_bk.js"></script>

            <script>
                $(function(){
                    fb = new Formbuilder({
                        selector: '.fb-main',
                        bootstrapData:getFormResponse(),
                        bootstrapPreloadData:getFormResponse()
                    });
          
                    function getFormResponse(){
                        $('.spinner').css('display','block');
                        var dataResult;
                        var m_feature_id = $("#m_feature_id").val();
                        var m_feature_sub_id = $("#m_feature_sub_id").val();
                        var m_feature_controller_ids = $("#m_feature_controller_ids").val();
                        $.ajax({
                            url: "loadSelectedFeatureController.php",
                            type: "POST",
                            async: false,
                            data: {m_feature_id:m_feature_id,m_feature_sub_id:m_feature_sub_id,m_feature_controller_ids:m_feature_controller_ids },
                            dataType: "json",
                            success: function (dataCheck) {
                                dataResult= dataCheck.form_response; // <==============================
                                $("#m_feature_controller_ids").val(dataCheck.m_feature_controller_ids);
                            }
                        });
                        $('.spinner').css('display','none');
                        return dataResult;
                    }
          
                    fb.on('save', function(payload){
                        $('.spinner').css('display','block');
                        var m_feature_id = $("#m_feature_id").val();
                        var m_feature_sub_id = $("#m_feature_sub_id").val();
                        var m_feature_controller_ids = $("#m_feature_controller_ids").val();
                        var request = $.ajax({
                            url: "saveProccessSubFeatureForm.php",
                            type: "POST",
                            data: { form_response : payload,m_feature_id:m_feature_id,m_feature_sub_id:m_feature_sub_id,m_feature_controller_ids:m_feature_controller_ids },
                            dataType: "json"
                        });
                        request.done(function( msg ) {
                            console.log(msg);
                            $('.spinner').css('display','none');
                            $("#m_feature_controller_ids").val(msg.list_controller_id)
                            //alert("saved");
                        });
                    })
                });
            </script>
        </div>
    </div>
</body>
</html>
