<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);

}

$sql = "SELECT a.m_feature_sub_id,c.feature,a.feature_sub,c.m_feature_id FROM m_feature_sub a INNER JOIN map_feature_sub b on a.m_feature_sub_id = b.m_feature_sub_id inner JOIN m_feature c on b.m_feature_id=c.m_feature_id WHERE c.m_feature_id=$m_feature_id and a.deleted_datentime is NULL and b.deleted_datentime is NULL and c.deleted_datentime is NULL ORDER BY b.feature_sub_order ASC";

$map_feature_sub  = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);


foreach ($map_feature_sub as $sub_feature) {

   $m_feature_sub_id =  $sub_feature['m_feature_sub_id'];

    $selectBox .= '<option value="' . $m_feature_sub_id . '">' . stripslashes(trim($sub_feature['feature_sub'])) . '</option>';
}

echo $selectBox;

?>