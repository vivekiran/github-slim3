<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

if(empty($validation_param)){
    $validation_param = 'N';
    $param_value = NULL;
}

if(empty($m_validation_id)){

    $m_validation = $disclosure_platform->m_validation()->insert(array(
        "validation_name" => $validation_name,
        "validation_alias" => $validation_alias,
        "param_value" => $param_value,
        "validation_param" => $validation_param,
        "validation_message" => $validation_message
    ));
} else {

    $disclosure_platform->m_validation()->insert_update(array("m_validation_id" => $m_validation_id), array(
        "validation_name" => $validation_name,
        "validation_alias" => $validation_alias,
        "param_value" => $param_value,
        "validation_param" => $validation_param,
        "validation_message" => $validation_message
    ));
}

header("location:masterValidations.php");