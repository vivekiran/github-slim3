<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


 $sql = 'SELECT * FROM m_validation ORDER BY  m_validation_id ASC';

$m_feature = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>




<!doctype html>
<html>
<head>
  <title>Master Common Validation Clients</title>
  <meta name="description" content="">
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
  <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
<div class="row">
 <div class="col-md-12">
    <!-- Standard button -->

  <h1>Validation Master List</h1>
<div style="float:right;"><a href="addValidation.php" class="btn btn-primary">Add Validation</a></div>
<div class="clear-fix"></div>
<form name="validateForm" id="validateForm" method="POST" action="">
<table cellpadding="0" cellspacing="0" border="0" class="table" id="table_feature_list" width="100%">
      <thead>
        <tr>
          <th>Validation name</th>
          <th>Validation Alias</th>
          <th>Edit</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($m_feature as $key => $value) { ?>
        <tr>
          <td><?=$value['validation_name']?></td>
          <td><?=$value['validation_alias']?></td>
          <td><a href="addValidation.php?edit=true&m_validation_id=<?=$value['m_validation_id']?>">Edit</a></td>
        </tr>
        <?php } ?>
      </tbody>

    </table>
  </form>
</div>
</div>
</div>
  <script type="text/javascript" src="vendor/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="dist/featureList.js"></script>
</body>
</html>