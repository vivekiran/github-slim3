<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

if(empty($m_feature_id)){

    $m_feature = $disclosure_platform->m_feature()->insert(array(
        "feature" => $enter_feature_name,
        "created_by"=> '-1',
        "created_datentime" => date("Y-m-d H:i:s"),
        "activated_by"=> '-1',
        "activated_datentime" => date("Y-m-d H:i:s")
    ));
} else {

    $disclosure_platform->m_feature()->insert_update(array("m_feature_id" => $m_feature_id), array("feature" => $enter_feature_name));
}

header("location:featureList.php");