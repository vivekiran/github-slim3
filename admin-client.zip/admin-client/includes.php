<?php
error_reporting(E_ALL & ~E_NOTICE);
//  configuration file for global declaration

if (file_exists('../project1/configs/config.php')){
    include '../project1/configs/config.php';
}elseif (file_exists('../../project1/configs/config.php')) {
   include '../../project1/configs/config.php';
}


require CLASS_PATH . 'class.connection.php';

if($_SERVER['REMOTE_ADDR']=='192.168.100.431'){
    $selectDB = DB_DBNAME;
} else {
    $selectDB = 'skeleton';
}

$connection = new PDO("mysql:host=".DB_HOSTNAME.";dbname=$selectDB", 'skeletonrwusr','skeletonusr4RWMOD');
$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$connection->setAttribute(PDO::ATTR_CASE, PDO::CASE_LOWER);
$disclosure_platform = new DBConnection($connection);
//$disclosure_platform->debug = true;
//

require CLASS_PATH . 'class.common.php';
$common = new CommonLib($disclosure_platform);

?>