<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


// Load Specific Referee Type Template
//
$sql = "SELECT  cf.m_feature_id,mf.feature
FROM  `client_feature` cf
LEFT JOIN m_feature mf ON cf.m_feature_id = mf.m_feature_id
WHERE cf.client_id =$client_id and mf.deleted_datentime is NULL and cf.deleted_datentime is NULL
GROUP BY  cf.`m_feature_id` ORDER BY cf.feature_order";

$map_feature_sub  = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);


$selectBox = '<select id="selectFeatures" class="multiselect" multiple="multiple" name="selectFeatures[]">';

foreach ($map_feature_sub as $sub_feature) {

   $m_feature_id =  $sub_feature['m_feature_id'];

    if(empty($selected_m_feature_id)){
        $selected_m_feature_id.=$m_feature_id;
    }else{
        $selected_m_feature_id.=",".$m_feature_id;
    }

    $selectBox .= '<option selected="selected" value="' . $m_feature_id . '">' . stripslashes(trim($sub_feature['feature'])) . '</option>';
}

$selectMasterFeatureSub = "SELECT a.m_feature_id,a.feature
  FROM m_feature a
  INNER JOIN map_feature_sub b on a.m_feature_id = b.m_feature_id
  WHERE a.deleted_datentime is NULL and b.deleted_datentime is NULL";

if(!empty($selected_m_feature_id))
$selectMasterFeatureSub.=" and a.m_feature_id NOT IN ($selected_m_feature_id) ";


$selectMasterFeatureSub.=" GROUP BY a.m_feature_id ORDER BY a.m_feature_id ASC,a.feature_order ASC ";

$map_feature_sub_list  = $connection->query($selectMasterFeatureSub)->fetchAll(PDO::FETCH_ASSOC);



foreach ($map_feature_sub_list as $sub_feature) {

   $m_feature_id  =  $sub_feature['m_feature_id'];


    $selectBox .= '<option value="' . $m_feature_id . '">' . stripslashes(trim($sub_feature['feature'])) . '</option>';
}

$selectBox .= '</select>';

echo json_encode(array(
    'objData' => $selectBox,
    'client_id' => $client_id,
    'selected_m_feature_id' => $selected_m_feature_id
));
?>