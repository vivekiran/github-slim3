<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if(!empty($m_feature_id)){
  $sql = "SELECT m_feature_id, feature FROM m_feature ";
  $sql .= "WHERE m_feature_id='$m_feature_id'";
  $m_feature = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

$feature_name = $m_feature['feature'];
?>




<!doctype html>
<html>
    <head>
        <title>Add feature</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
      
    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
                <div class="jumbotron">
                    
                <h2>Add/Update Feature</h2>
                <form action="processAddUpdateFeature.php" class="form-horizontal" method="post" role="form">
                    <input type="hidden" name="m_feature_id" id="m_feature_id" value="<?php echo $m_feature_id ?>" />
                    <div class="form-group">
                        <label for="form_name" class="col-sm-2 control-label">Enter Feature name</label>
                        <div class="col-sm-10">
                            <input required="required" type="text" name="enter_feature_name" class="form-control" id="enter_feature_name" value="<?php echo $feature_name; ?>" />
                        </div>
                    </div>
                        
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>

                </form>

            </div>
        </div>


    </body>
</html>