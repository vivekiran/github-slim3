<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if(!empty($m_validation_id)){
  $sql = "SELECT * FROM m_validation ";
  $sql .= "WHERE m_validation_id='$m_validation_id'";
  $m_validation = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

?>




<!doctype html>
<html>
<head>
  <title>Add feature</title>
  <meta name="description" content="">
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
  <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
  <link type="text/css" rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/ui-lightness/jquery-ui.css" />
</head>
<body>
<div class="container">
<div class="row">
 <div class="col-md-12">
  <h1>Add/Update Feature</h1>
  <form action="processAddUpdateValidation.php" method="post" role="form">
    <input type="hidden" name="m_validation_id" id="m_validation_id" value="<?php echo $m_validation_id?>" />
  <div class="form-group">
    <label for="form_name">Enter Validaton name</label>
    <input required="required" type="text" name="validation_name" id="validation_name" value="<?php echo $m_validation['validation_name'];?>" />
  </div>
    <div class="form-group">
    <label for="form_name">Enter Validaton Alias</label>
    <input required="required" type="text" name="validation_alias" id="validation_alias" value="<?php echo $m_validation['validation_alias'];?>" />
  </div>
    <div class="form-group">
    <label for="form_name">Enter Validaton Message</label>
    <textarea required="required" type="text" name="validation_message" id="validation_message" rows="4" cols="50"/><?php echo $m_validation['validation_message'];?> </textarea>(%f for field and %n for param value)
  </div>
      <div class="form-group">
    <label for="form_name">Validaton Param</label>
    <input type="checkbox" name="validation_param" id="validation_param" value="Y" <?php if($m_validation['validation_param']=='Y'){ ?>} checked="checked" <?php } ?> />

  </div>
    <div class="form-group" id="paramValueDisplay">
    <label for="form_name">Param Value</label>
    <input type="text" name="param_value" id="param_value" value="<?php echo $m_validation['param_value']; ?>" />

  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
</div>
</div>
</div>

 <script>
$(function() {

$("#paramValueDisplay").css("display","none");

var CheckParmCheckedOrNot = $("#validation_param").attr('checked');


 $( "#validation_name" ).autocomplete({
  source: "listAllValidation.php",
  minLength: 1,
  select: function( event, ui ) {
  }
});

$("#validation_param").click(function() {
  var thisValue = $(this).attr("checked");
  $("#param_value").val('');
  if(thisValue=='checked'){
  $("#paramValueDisplay").css({
    display: 'block'
  });
} else{
    $("#paramValueDisplay").css({
    display: 'none'
  });
}
});

if(CheckParmCheckedOrNot=='checked'){
$("#paramValueDisplay").css({
    display: 'block'
  });
}


 });

</script>
</body>
</html>