<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$m_forms = $disclosure_platform->m_forms()->insert(array(
    "m_client_id" => $hidden_client_id,
    "form_name" => $form_name,
    "form_description" => $form_description
));
$insert_id = $disclosure_platform->m_forms()->insert_id();

header("location:form.php?form_id=$insert_id&clientid=$hidden_client_id");