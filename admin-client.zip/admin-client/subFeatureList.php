<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$sql = 'SELECT m_feature_sub_id, feature_sub FROM m_feature_sub

 WHERE deleted_datentime is NULL  ORDER BY  m_feature_sub_id ASC';

$m_feature = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>



    
<!doctype html>
<html>
    <head>
        <title>Sub Feature</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
      
    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">
    
                <!-- Standard button -->
        
                <h2>Sub Feature Feature List</h2>
                <div style="float:right;"><a href="addSubFeature.php" class="btn btn-primary">Add Sub Feature</a></div>
                <div class="clear-fix"></div>
                <form name="validateForm" id="validateForm" method="POST" action="">
                    <table cellpadding="0" cellspacing="0" border="0" class="table" id="table_feature_list" width="100%">
                        <thead>
                            <tr>
                                <th>Sub Feature name</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($m_feature as $key => $value) { ?>
                                <tr>
                                    <td><?= $value['feature_sub'] ?></td>
                                    <td><a href="addSubFeature.php?edit=true&m_feature_sub_id=<?= $value['m_feature_sub_id'] ?>">Edit</a></td>
                                    <td><a onclick="deleteSubFeature(<?= $value['m_feature_sub_id'] ?>);" href="javascript:void(0);">Delete</a></td>
                                </tr>
                            <?php } ?>
                        </tbody>
          
                    </table>
                </form>
      
            </div>
        </div>
        <script type="text/javascript" src="vendor/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="dist/featureSubList.js"></script>
    </body>
</html>