<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

function removeslashes($string)
{
    $string=implode("",explode("\\",$string));
    return stripslashes(trim($string));
}


$html_element_attribute = $disclosure_platform->html_element_attribute(array("html_element_id = ?"=>$html_element_id))->fetchAll(PDO::FETCH_ASSOC);


$field_attribute_array = array();
if(!empty($field_id)){
    $field_attribute = $disclosure_platform->field_attribute(array("field_id = ?"=>$field_id))->fetchAll(PDO::FETCH_ASSOC);


    foreach ($field_attribute['data'] as $html_element_attribute_key => $html_element_attribute_value) {

        if(!empty($html_element_attribute_value['attribute_value']))
        $field_attribute_array[$html_element_attribute_value['attribute_name']] = $html_element_attribute_value['attribute_value'];

    }
}

$inputCheckBox = null;

foreach ($html_element_attribute['data'] as $html_element_attribute_key => $html_element_attribute_value) {

    $checkedValue = null;
    $fieldValue = null;



    $html_element_id = $html_element_attribute_value['html_element_id'];
    $html_element_attribute_value = $html_element_attribute_value['attribute_name'];

    $checkedValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? "checked":"");
    $fieldValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? $field_attribute_array[$html_element_attribute_value]:'');
    $inputCheckBox.=' <input '.$checkedValue.' type="checkbox" name="add_attribute[]" value="'.$html_element_attribute_value.'" /> '.ucfirst($html_element_attribute_value);
    if($html_element_id=='10'){
        $inputCheckBox.="<br />";

        if($html_element_attribute_value=='content_key')
       $inputCheckBox.='<input type="text" name="add_attribute_value['.$html_element_attribute_value.']" value="'.$fieldValue.'" />';
        else
        $inputCheckBox.='<textarea rows="20" cols="50" name="add_attribute_value['.$html_element_attribute_value.']">'.removeslashes($fieldValue).'</textarea>';
    }else{
        $inputCheckBox.='<input type="text" name="add_attribute_value['.$html_element_attribute_value.']" value="'.$fieldValue.'" />';
    }
    $inputCheckBox.="<br />";

}

echo $inputCheckBox;

?>