<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Admin Form Builder</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Modules <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="moduleList.php">View Modules</a></li>
            <li><a href="addModule.php">Add Module</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Sections <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="sectionList.php">View Sections</a></li>
            <li><a href="addSection.php">Add Sections</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="pageList.php">View Pages</a></li>
            <li><a href="addPage.php">Add Page</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Fieldsets <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="fieldsetList.php">View Fieldsets</a></li>
            <li><a href="addFieldset.php">Add Fieldset</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Fields <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="fieldList.php">View Fields</a></li>
            <li><a href="addField.php">Add Fields</a></li>
          </ul>
        </li>
<!--         <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Maping<b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="mapFeatureSubFeature.php">Map Sub/Features</a></li>

            <li><a href="selectSubFeatureForm.php">Map Feature to form</a></li>
            <li><a href="selectDependencySubFeatureForm.php">Map Control Dependency</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Client<b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="selectMapFeatureClient.php">Map Feature</a></li>
            <li><a href="selectMapSubFeatureClient.php">Map Sub Feature</a></li>
            <li><a href="selectMapControllClient.php">Map Controls</a></li>
          </ul>
        </li> -->
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>