<?php
error_reporting(E_ALL | E_STRICT);
include dirname(__FILE__) . "/../NotORM.php";

$connection = new PDO("mysql:host=192.168.100.212;dbname=skeleton_live", "billinguser","billingpass");
$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
$connection->setAttribute(PDO::ATTR_CASE, PDO::CASE_LOWER);
$skeleton = new NotORM($connection);
$skeleton->debug = true;

echo "<pre>";
print_r($connection);
echo "</pre>";
exit;