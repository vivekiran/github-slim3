<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$m_forms = $disclosure_platform->m_forms(array("m_form_id"=>$form_id,"m_client_id"=>$clientid))->fetch();

if(empty($m_forms['form_response'])){
  $form_response = '[]';
}else{
  $form_response = $m_forms['form_response'];
}

?>
<!doctype html>
<html>
<head>
  <title>Form Builder</title>
  <meta name="description" content="">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
  <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="vendor/css/vendor.css" />
  <link rel="stylesheet" href="dist/formbuilder.css" />
  <style>
  * {
    box-sizing: border-box;
  }

  body {
    background-color: #444;
    font-family: sans-serif;
  }

  .fb-main {
    background-color: #fff;
    border-radius: 5px;
    min-height: 600px;
  }

  input[type=text] {
    height: 26px;
    margin-bottom: 3px;
  }

  select {
    margin-bottom: 5px;
    font-size: 40px;
  }
  </style>
</head>
<body>
  <div class="container">
<div class="row">
<input type="hidden" name="hidden_form_id" id="hidden_form_id" value="<?=$m_forms['m_form_id']?>" />
<input type="hidden" name="hidden_client_id" id="hidden_client_id" value="<?=$clientid?>" />

<h1><?=$m_forms['form_name']?></h1>
</div>

  <div class="row">
  <div class='fb-main'></div>

  <script src="vendor/js/vendor.js"></script>
  <script src="dist/formbuilder_bk.js"></script>

  <script>
    $(function(){
      fb = new Formbuilder({
        selector: '.fb-main',
        bootstrapData: <?=$form_response?>
      });

      fb.on('save', function(payload){
        var hidden_form_id = $("#hidden_form_id").val();
        var hidden_client_id = $("#hidden_client_id").val();
          var request = $.ajax({
            url: "saveform_response.php",
            type: "POST",
            data: { form_response : payload,form_id:hidden_form_id,clientid:hidden_client_id },
            dataType: "html"
          });
          request.done(function( msg ) {
            console.log(msg);
            //alert("saved");
        });
      })
    });
  </script>
</div>
</div>
</body>
</html>