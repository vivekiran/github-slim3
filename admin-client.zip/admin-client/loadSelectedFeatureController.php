<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);

}

//sleep(2);


function getControllerOption($disclosure_platform,$m_control_id){
  $m_control_option = $disclosure_platform->m_control_option()->select("option_label as label,option_value as value,option_checked as checked")->where("m_control_id = ?",$m_control_id)->where("deleted_datentime",null)->fetchAllOption(PDO::FETCH_ASSOC);

  return $m_control_option;
}


$fields_query = "SELECT c.m_control_id as control_id,a.control_label as label, c.control_type as field_type, a.description, c.control_name as field_element_name, c.control_name as field_element_id,  c.control_name as cid, a.control_tooltip as tool_tip, group_concat(mv.validation_name) as validations,if(a.common_control='Y',1,'') as common_field,
group_concat(mv.validation_message) validation_message
FROM
m_control c
INNER JOIN map_feature_sub_control a ON c.m_control_id = a.m_control_id AND a.activated_datentime IS NOT NULL AND a.deleted_datentime IS NULL
INNER JOIN map_feature_sub mfs ON a.m_feature_sub_id = mfs.m_feature_sub_id AND mfs.activated_datentime IS NOT NULL AND mfs.deleted_datentime is NULL
LEFT JOIN map_validation mapv on a.map_feature_sub_control_id = mapv.map_feature_sub_control_id AND mapv.activated_datentime IS NOT NULL AND mapv.deleted_datentime IS NULL
LEFT JOIN map_control_validation mcv ON mapv.map_control_validation_id = mcv.map_control_validation_id AND mcv.activated_datentime IS NOT NULL AND mcv.deleted_datentime IS NULL
LEFT JOIN validation_common vc on mapv.map_validation_id = vc.map_validation_id AND vc.deleted_datentime is NULL
LEFT JOIN m_validation mv ON mcv.m_validation_id = mv.m_validation_id AND mv.activated_datentime IS NOT NULL AND mv.deleted_datentime IS NULL
WHERE c.activated_datentime IS NOT NULL AND c.deleted_datentime IS NULL AND a.m_feature_sub_id ='" . $m_feature_sub_id . "' AND mfs.m_feature_id = '" . $m_feature_id . "' AND c.control_type NOT IN ('button','html') AND c.deleted_datentime is NULL
GROUP BY
    c.m_control_id ORDER BY control_order ASC";

$fields = $connection->query($fields_query)->fetchAll(PDO::FETCH_ASSOC);

$ffields = array();

$m_feature_controller_ids = null;
foreach ($fields as $key => $field) {

    $control_id = null;
    $m_control_option = 0;
    $control_type = null;
    $common_control = null;
    $control_id = $field['control_id'];
    $control_type = $field['field_type'];

    $m_control_option = getControllerOption($disclosure_platform,$control_id);


    $ffields[$key] = $field;

    if ($field['validations'] != '') {

        $ffields[$key]['field_validations'] = array_fill_keys(explode(',' , $field['validations']), true);
    }

    $ffields[$key]['field_options'] = array(
        'description' => $field['description']
    );

    if($control_type=='radio' || $control_type=='dropdown' || $control_type=='checkbox'){

        $ffields[$key]['field_options']['options'] = $m_control_option;

    }
    if(empty($m_feature_controller_ids))
      $m_feature_controller_ids.=$control_id;
    else
      $m_feature_controller_ids.=",".$control_id;

    unset($ffields[$key]['validations']);
}

//$form_response = json_encode($ffields);

echo json_encode(array(
    'form_response' => $ffields,
    'm_feature_controller_ids' => $m_feature_controller_ids
));
?>