<?php
include_once dirname(__FILE__) . '../../includes.php';

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


if (!empty($html_element_id) && !empty($field_id)) {
    $sql = "SHOW tables";
    $listOfTables = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}


?>


<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">Field Properties</h4>
</div>
<form name="processValidateForm" id="processValidateForm" action="" method="post" role="form">
    <input type="hidden" name="html_element_id" id="html_element_id" value="<?= $html_element_id ?>" />
    <input type="hidden" name="field_id" id="field_id" value="<?= $field_id ?>" />


    <div class="modal-body">
                        <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select Source Table</label>
                     <div class="col-sm-9">
                    <select name="table_name" id="table_name" required="required" class="form-control">
                        <option value="">--Select Source Table--</option>
                        <?php
                        foreach ($listOfTables as $tableKey=>$tableName) {
                      echo '<option value="'.$tableName['tables_in_skeleton_demo'].'">'.$tableName['tables_in_skeleton_demo'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>
        <div class="form-group">
            <h2>List Of Properties</h2>
        </div>
         <table class="table">
      <thead>
        <tr>
          <th>Attribute Name</th>
          <th>Attribute Value</th>
        </tr>
      </thead>
      <tbody>
          <?php
$inputCheckBox = null;

foreach ($html_element_attribute['data'] as $html_element_attribute_key => $html_element_attribute_value) {

    $checkedValue = null;
    $fieldValue = null;



    $html_element_id = $html_element_attribute_value['html_element_id'];
    $html_element_attribute_value = $html_element_attribute_value['attribute_name'];

    $checkedValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? "checked":"");
    $fieldValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? $field_attribute_array[$html_element_attribute_value]:'');
    if(!empty($checkedValue)){
    ?>
    <tr>
          <td><?=strtoupper($html_element_attribute_value)?></td>
           <td><?=strtoupper($fieldValue)?></td>
    </tr>
 <?php } }    ?>

      </tbody>
    </table>

    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
</form>