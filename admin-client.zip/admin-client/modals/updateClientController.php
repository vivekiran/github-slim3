<?php
include_once dirname(__FILE__) . '../../includes.php';


foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$validationId = $_POST['validationId'];


if(!empty($map_feature_sub_control_id)){


    if(!empty($listClientValidationIds) && !empty($listClientMessageValidationIds)){

            $explodeClientValidationId = explode(",", $listClientValidationIds);

            $explodeClientMesssageId = explode(",", $listClientMessageValidationIds);

            $validation_client = $disclosure_platform->validation_client()->where("validation_client_id",$explodeClientValidationId)->where("client_id",$client_id);

            $validation_message = $disclosure_platform->validation_message()->where("validation_message_id",$explodeClientMesssageId)->where("client_id",$client_id);

            $updatedControlData = array(
                "deleted_by" => -1,
                "deleted_datentime" => date("Y-m-d H:i:s")
            );
            $validation_client->update($updatedControlData);
            $validation_message->update($updatedControlData);


        }


     $client_feature_control = $disclosure_platform->client_feature_control()->where("client_id",$client_id)->where("map_feature_sub_control_id = ?",$map_feature_sub_control_id);

        if(empty($control_label)){
            $control_label = null;
        }
        if(empty($control_tooltip)){
            $control_tooltip = null;
        }

      if($client_feature_control->count() > 0) {
                $data_results = array(
                "control_label" => $control_label,
                "control_tooltip"=>$control_tooltip,
                "deleted_by" => NULL,
                "deleted_datentime" => NULL
            );
            $client_feature_control->update($data_results);
        }

       foreach ($validationId as $key => $validation_value) {
                $m_validation_id = null;
                $validation_message = null;
                $m_validation_id = $validation_value;
                $validation_message = $_POST['validationMessage_'.$m_validation_id];

                $map_control_validation_result = $disclosure_platform->map_control_validation()->where("m_control_id",$m_control_id)->where("m_validation_id",$m_validation_id);



                if($map_control_validation_result->count()==0){
                            $map_control_validation = $disclosure_platform->map_control_validation()->insert(array(
                                "m_control_id" => $m_control_id,
                                "m_validation_id" => $m_validation_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activate_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));
                            $map_control_validation_id = null;
                            $map_control_validation_id = $disclosure_platform->map_control_validation()->insert_id();
                    } elseif ($map_control_validation_result->count()>0) {
                       $dataUpdateMapControlValidation = array(
                            "deleted_by" => null,
                            "deleted_datentime" => null
                        );
                       $map_control_validation_result->update($dataUpdateMapControlValidation);
                    }

                $set_control_validation_id = null;

                $set_control_validation_id = $map_control_validation_result[0]['map_control_validation_id'];

                $map_validation_result = $disclosure_platform->map_validation()->where("map_control_validation_id",$set_control_validation_id)->where("map_feature_sub_control_id",$map_feature_sub_control_id);

                    if(empty($map_control_validation_id)){
                        $map_control_validation_id = $set_control_validation_id;
                    }

                    if($map_validation_result->count()==0){
                             $map_validation = $disclosure_platform->map_validation()->insert(array(
                                "map_feature_sub_control_id" => $map_feature_sub_control_id,
                                "map_control_validation_id" => $map_control_validation_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activate_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));

                             $map_validation_id = null;

                            $map_validation_id = $disclosure_platform->map_validation()->insert_id();
                        } elseif ($map_validation_result->count()>0) {
                           $dataUpdateMapControlValidation = array(
                                "deleted_by" => null,
                                "deleted_datentime" => null
                            );
                           $map_validation_result->update($dataUpdateMapControlValidation);
                        }

                    $set_map_validation_id = null;

                    $set_map_validation_id = $map_validation_result[0]['map_validation_id'];


                    $validation_client_result = $disclosure_platform->validation_client()->where("map_validation_id",$set_map_validation_id)->where("client_id",$client_id);


                    $validation_client_message_result = $disclosure_platform->validation_message()->where("map_validation_id",$set_map_validation_id)->where("client_id",$client_id);

                        if(empty($map_validation_id)){
                            $map_validation_id = $set_map_validation_id;
                        }


                        if($validation_client_result->count()==0){
                             $validation_client = $disclosure_platform->validation_client()->insert(array(
                                "map_validation_id" => $map_validation_id,
                                "client_id" => $client_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activate_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));
                        } elseif ($validation_client_result->count()>0) {
                           $dataUpdateMapControlValidation = array(
                                "deleted_by" => null,
                                "deleted_datentime" => null
                            );
                           $validation_client_result->update($dataUpdateMapControlValidation);
                        }


                         if($validation_client_message_result->count()==0){
                             $validation_message = $disclosure_platform->validation_message()->insert(array(
                                "map_validation_id" => $map_validation_id,
                                "validation_message"=>$validation_message,
                                "client_id" => $client_id,
                                "created_by"=> '-1',
                                "created_datentime" => date("Y-m-d H:i:s"),
                                "activated_by"=> '-1',
                                "activated_datentime" => date("Y-m-d H:i:s")
                            ));
                        } elseif ($validation_client_message_result->count()>0) {
                           $dataUpdateMapControlValidation = array(
                                "validation_message"=>$validation_message,
                                "deleted_by" => null,
                                "deleted_datentime" => null
                            );
                           $validation_client_message_result->update($dataUpdateMapControlValidation);
                        }




       }




}