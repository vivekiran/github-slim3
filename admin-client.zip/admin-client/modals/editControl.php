<?php
include_once dirname(__FILE__) . '../../includes.php';


foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$sql = " SELECT mfsc.map_feature_sub_control_id, mf.m_feature_id, mf.feature, mfsb.m_feature_sub_id, mfsb.feature_sub, mc.m_control_id, mc.control_name, if(cfc.client_feature_control_id is not null,'Y','N') enabled_disabled,mc.control_type, if(cfc.control_label is not null,cfc.control_label,mfsc.control_label) control_label,
 if(cfc.control_tooltip is not null,cfc.control_tooltip,mfsc.control_tooltip) control_tooltip,mfsc.description,mfsc.map_feature_sub_control_id
FROM map_feature_sub mfs
INNER JOIN m_feature mf on mfs.m_feature_id = mf.m_feature_id
INNER JOIN m_feature_sub mfsb on mfs.m_feature_sub_id = mfsb.m_feature_sub_id
INNER JOIN map_feature_sub_control mfsc on mfs.m_feature_sub_id = mfsc.m_feature_sub_id
INNER JOIN m_control mc on mfsc.m_control_id = mc.m_control_id
LEFT JOIN client_feature_control cfc on mfsc.map_feature_sub_control_id = cfc.map_feature_sub_control_id and cfc.client_id = $client_id
where mc.control_type NOT IN('button') AND mfs.m_feature_id = $selectFeature and mfs.m_feature_sub_id = $selectSubFeature AND mfsc.map_feature_sub_control_id =$map_control_id  ORDER BY cfc.control_order ASC, mfsc.control_order ASC";

$view_client_control = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

$map_feature_sub_control_id = $view_client_control[0]['map_feature_sub_control_id'];

$m_control_id = $view_client_control[0]['m_control_id'];


$selectCommonValidation = " SELECT *
FROM view_validation
where map_feature_sub_control_id='$map_feature_sub_control_id'";

$resultCommonValidation = $connection->query($selectCommonValidation)->fetchAll(PDO::FETCH_ASSOC);


$list_of_validation = array();
$j = 0;
$listValidationIds = null;
$listClientValidationIds = null;
$listClientMessageValidationIds = null;
for ($i=0; $i < count($resultCommonValidation); $i++) {
  $validation_client_id = null;
  $validation_client_id = $resultCommonValidation[$i]['validation_client_id'];

  $validation_message_id = null;
  $validation_message_id = $resultCommonValidation[$i]['validation_message_id'];

  if(empty($listValidationIds)){
    $listValidationIds.= $resultCommonValidation[$i]['m_validation_id'];
  } else {
      $listValidationIds.=",".$resultCommonValidation[$i]['m_validation_id'];
  }

  if(empty($listClientValidationIds) && !empty($validation_client_id)){
    $listClientValidationIds.= $validation_client_id;
  } elseif(!empty($listClientValidationIds) && !empty($validation_client_id)) {
      $listClientValidationIds.=",".$validation_client_id;
  }

  if(empty($listClientMessageValidationIds) && !empty($validation_message_id)){
    $listClientMessageValidationIds.= $validation_message_id;
  } elseif(!empty($listClientMessageValidationIds) && !empty($validation_message_id)) {
      $listClientMessageValidationIds.=",".$validation_message_id;
  }

$list_of_validation[$j]['validation_client_id']          = $resultCommonValidation[$i]['validation_client_id'];
  $list_of_validation[$j]['map_validation_id']          = $resultCommonValidation[$i]['map_validation_id'];
  $list_of_validation[$j]['m_validation_id']            = $resultCommonValidation[$i]['m_validation_id'];
  $list_of_validation[$j]['validation_name']            = $resultCommonValidation[$i]['validation_name'];
  $list_of_validation[$j]['validation_alias']           = $resultCommonValidation[$i]['validation_alias'];
  $list_of_validation[$j]['validation_parameter']       = $resultCommonValidation[$i]['validation_parameter'];
  $list_of_validation[$j]['validation_message']         = $resultCommonValidation[$i]['validation_message'];
  $list_of_validation[$j]['client_validation']          = $resultCommonValidation[$i]['client_validation'];
  $j++;
}

$m_validation.= "SELECT * FROM m_validation WHERE activated_datentime is not null and deleted_datentime is null ";


if(!empty($listValidationIds)){
  $m_validation.=" AND m_validation_id NOT IN ($listValidationIds)";
}

$validation_m_result = $connection->query($m_validation)->fetchAll(PDO::FETCH_ASSOC);


for ($k=0; $k < count($validation_m_result) ; $k++) {
  $list_of_validation[$j]['map_validation_id']          = null;
  $list_of_validation[$j]['validation_client_id']            = null;
  $list_of_validation[$j]['m_validation_id']            = $validation_m_result[$k]['m_validation_id'];
  $list_of_validation[$j]['validation_name']            = $validation_m_result[$k]['validation_name'];
  $list_of_validation[$j]['validation_alias']           = $validation_m_result[$k]['validation_alias'];
  $list_of_validation[$j]['validation_parameter']       = $validation_m_result[$k]['validation_parameter'];
  $list_of_validation[$j]['validation_message']         = $validation_m_result[$k]['validation_message'];
  $list_of_validation[$j]['client_validation']          = null;
  $j++;
}



?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">Update Controller</h4>
</div>
<form name="processValidateForm" id="processValidateForm" action="" method="post" role="form">
    <input type="hidden" name="client_id" id="client_id" value="<?= $client_id ?>" />
    <input type="hidden" name="selectFeature" id="selectFeature" value="<?= $selectFeature ?>" />
    <input type="hidden" name="selectSubFeature" id="selectSubFeature" value="<?= $selectSubFeature ?>" />
    <input type="hidden" name="m_control_id" id="m_control_id" value="<?= $m_control_id ?>" />
    <input type="hidden" name="map_feature_sub_control_id" id="map_feature_sub_control_id" value="<?= $map_feature_sub_control_id ?>" />


      <input type="hidden" name="listClientValidationIds" id="listClientValidationIds" value="<?= $listClientValidationIds ?>" />
  <input type="hidden" name="listClientMessageValidationIds" id="listClientMessageValidationIds" value="<?= $listClientMessageValidationIds ?>" />


    <div class="modal-body">
        <div class="form-group">
            <label for="form_name">Label</label>
            <input required="required" type="text" class="form-control" name="control_label" id="control_label" value="<?= $view_client_control[0]['control_label'] ?>" />

        </div>
        <div class="form-group">
            <label for="form_name">Tooltip</label>
            <textarea required="required" class="form-control" name="control_tooltip" id="control_tooltip"><?= $view_client_control[0]['control_tooltip'] ?></textarea>
        </div>
        <div class="form-group">
            <label for="form_name">Description</label>
            <?= $view_client_control[0]['description'] ?>
        </div>
        <div class="form-group">
            <h2>List Of Validation</h2>
        </div>
         <table class="table">
      <thead>
        <tr>
          <th>Select</th>
          <th>Validation Name</th>
          <th>Validation Message</th>
        </tr>
      </thead>
      <tbody>
          <?php
  foreach ($list_of_validation as $validationkey => $validation_message) {?>
        <tr>
          <td><input type="checkbox" name="validationId[]" value="<?=$validation_message['m_validation_id']?>" <?php if($validation_message['client_validation']=='N') {?> checked="checked" disabled="disabled" <?php } ?> <?php if(!empty($validation_message['validation_client_id'])) {?> checked="checked"  <?php } ?>/></td>
          <td><?=$validation_message['validation_alias']?></td>
          <td><?php if($validation_message['client_validation']!='N') { ?>
            <textarea name="validationMessage_<?=$validation_message['m_validation_id']?>"><?=$validation_message['validation_message']?></textarea>
            <?php } else { ?> <?=$validation_message['validation_message']?> <?php  } ?></td>
        </tr>
 <?php }   ?>

      </tbody>
    </table>

    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button id="saveController" type="button" class="btn btn-primary">Save changes</button>
    </div>
</form>