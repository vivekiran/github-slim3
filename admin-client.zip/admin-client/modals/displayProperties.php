<?php
include_once dirname(__FILE__) . '../../includes.php';

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$html_element_attribute = $disclosure_platform->html_element_attribute(array("html_element_id = ?"=>$html_element_id))->fetchAll(PDO::FETCH_ASSOC);


$field_attribute_array = array();
if(!empty($field_id)){
    $field_attribute = $disclosure_platform->field_attribute(array("field_id = ?"=>$field_id))->fetchAll(PDO::FETCH_ASSOC);


    foreach ($field_attribute['data'] as $html_element_attribute_key => $html_element_attribute_value) {

        if(!empty($html_element_attribute_value['attribute_value']))
        $field_attribute_array[$html_element_attribute_value['attribute_name']] = $html_element_attribute_value['attribute_value'];

    }
}

$inputCheckBox = null;

foreach ($html_element_attribute['data'] as $html_element_attribute_key => $html_element_attribute_value) {

    $checkedValue = null;
    $fieldValue = null;



    $html_element_id = $html_element_attribute_value['html_element_id'];
    $html_element_attribute_value = $html_element_attribute_value['attribute_name'];

    $checkedValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? "checked":"");
    $fieldValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? $field_attribute_array[$html_element_attribute_value]:'');
    $inputCheckBox.=' <input '.$checkedValue.' type="checkbox" name="add_attribute[]" value="'.$html_element_attribute_value.'" /> '.ucfirst($html_element_attribute_value);
    if($html_element_id=='10'){
        $inputCheckBox.="<br />";
        $inputCheckBox.='<textarea rows="20" cols="90" name="add_attribute_value['.$html_element_attribute_value.']">'.$fieldValue.'</textarea>';
    }else{
        $inputCheckBox.='<input type="text" name="add_attribute_value['.$html_element_attribute_value.']" value="'.$fieldValue.'" />';
    }
    $inputCheckBox.="<br />";

}
?>


<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">Field Properties</h4>
</div>
<form name="processValidateForm" id="processValidateForm" action="" method="post" role="form">
    <input type="hidden" name="client_id" id="client_id" value="<?= $client_id ?>" />
    <input type="hidden" name="selectFeature" id="selectFeature" value="<?= $selectFeature ?>" />
    <input type="hidden" name="selectSubFeature" id="selectSubFeature" value="<?= $selectSubFeature ?>" />
    <input type="hidden" name="m_control_id" id="m_control_id" value="<?= $m_control_id ?>" />
    <input type="hidden" name="map_feature_sub_control_id" id="map_feature_sub_control_id" value="<?= $map_feature_sub_control_id ?>" />


      <input type="hidden" name="listClientValidationIds" id="listClientValidationIds" value="<?= $listClientValidationIds ?>" />
  <input type="hidden" name="listClientMessageValidationIds" id="listClientMessageValidationIds" value="<?= $listClientMessageValidationIds ?>" />


    <div class="modal-body">
        <div class="form-group">
            <h2>List Of Properties</h2>
        </div>
         <table class="table">
      <thead>
        <tr>
          <th>Attribute Name</th>
          <th>Attribute Value</th>
        </tr>
      </thead>
      <tbody>
          <?php
$inputCheckBox = null;

foreach ($html_element_attribute['data'] as $html_element_attribute_key => $html_element_attribute_value) {

    $checkedValue = null;
    $fieldValue = null;



    $html_element_id = $html_element_attribute_value['html_element_id'];
    $html_element_attribute_value = $html_element_attribute_value['attribute_name'];

    $checkedValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? "checked":"");
    $fieldValue = (array_key_exists($html_element_attribute_value,$field_attribute_array) ? $field_attribute_array[$html_element_attribute_value]:'');
    if(!empty($checkedValue)){
    ?>
    <tr>
          <td><?=($html_element_attribute_value)?></td>
           <td><?=($fieldValue)?></td>
    </tr>
 <?php } }    ?>

      </tbody>
    </table>

    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
</form>