<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$client_id = trim($_POST['select_client']);
$selectFeatures = $_POST['selectFeatures'];
$list_of_feature_selected = $_POST['list_of_feature_selected'];

if(!empty($list_of_feature_selected)){
    $explode_list_of_feature_selected = explode(",",$list_of_feature_selected);
}


$client_feature = $disclosure_platform->client_feature()->where("client_id",$client_id)->where("m_feature_id",$explode_list_of_feature_selected);



if($client_feature->count()==0){

    $countZeroOrder = 1;
    foreach ($selectFeatures as $key => $value) {
            $m_feature = $disclosure_platform->client_feature()->insert(array(
            "client_id" => $client_id,
            "m_feature_id" => $value,
            "feature_order" => $countZeroOrder,
            "created_by"=> '-1',
            "created_datentime" => date("Y-m-d H:i:s"),
            "activate_by"=> '-1',
            "activated_datentime" => date("Y-m-d H:i:s")
        ));
        $countZeroOrder++;
    }
} else{
    $data = array(
        "feature_order" => NULL,
        "deleted_by" => -1,
        "deleted_datentime" => date("Y-m-d H:i:s")
    );
    $client_feature->update($data);
    $countZeroOrder = 1;
    foreach ($selectFeatures as $key => $value) {
        $client_feature_results = $disclosure_platform->client_feature()->where("client_id",$client_id)->where("m_feature_id",$value);


        if($client_feature_results->count()==0){
                $m_feature = $disclosure_platform->client_feature()->insert(array(
                "client_id" => $client_id,
                "m_feature_id" => $value,
                "created_by"=> '-1',
                "feature_order" => $countZeroOrder,
                "created_datentime" => date("Y-m-d H:i:s"),
                "activate_by"=> '-1',
                "activated_datentime" => date("Y-m-d H:i:s")
            ));
        } else {
                $data_results = array(
                 "feature_order" => $countZeroOrder,
                "deleted_by" => NULL,
                "deleted_datentime" => NULL
            );
            $client_feature_results->update($data_results);
        }
        $countZeroOrder++;
    }
}


header("location:mapClientFeature.php?select_client=$client_id");