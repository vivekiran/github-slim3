<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);

}

$sql = "SELECT  *
FROM  `view_client_feature_sub`
WHERE client_id =$client_id
AND  `m_feature_id`  =$m_feature_id ORDER BY forder asc";


$map_feature_sub  = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);


foreach ($map_feature_sub as $sub_feature) {

   $m_feature_sub_id =  $sub_feature['m_feature_sub_id'];

    $selectBox .= '<option value="' . $m_feature_sub_id . '">' . stripslashes(trim($sub_feature['feature_sub'])) . '</option>';
}

echo $selectBox;

?>