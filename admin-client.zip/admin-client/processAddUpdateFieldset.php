<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

if(empty($fieldset_id)){

    $fieldset = $disclosure_platform->fieldset()->insert(array(
        "fieldset_name" => $enter_fieldset_name,
        "page_id" => $page_id,
        "page_type_id"=>$page_type_id
    ));
} else {

    $disclosure_platform->fieldset()->insert_update(array("fieldset_id" => $fieldset_id), array(
        "fieldset_name" => $enter_fieldset_name,
        "page_id" => $page_id,
        "page_type_id"=>$page_type_id
    ));
}

header("location:fieldsetList.php");