<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$sql.= 'SELECT s.section_id,m.module_id,m.module_name,s.section_name,s.section_description FROM section s
INNER JOIN module m ON s.module_id = m.module_id ';

if(!empty($module_id))
$sql.= ' WHERE s.module_id='.$module_id;

if(!empty($section_id))
$sql.= ' WHERE s.section_id='.$section_id;

$sql.= ' ORDER BY section_id ASC';

$section = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>





<!doctype html>
<html>
    <head>
        <title>Section List</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <!-- Standard button -->

                <h2>Section List</h2>
                <div style="float:right;"><a href="addSection.php?fetchModule=<?=$module_id?>&fetchSection=<?=$section_id?>" class="btn btn-primary">Add Section</a></div>
                <div class="clear-fix"></div>
                <form name="validateForm" id="validateForm" method="POST" action="">
                    <table cellpadding="0" cellspacing="0" border="0" class="table" id="table_feature_list" width="100%">
                        <thead>
                            <tr>
                                <th>Module Name</th>
                                <th>Section Name</th>
                                <th>Section Description</th>
                                <th>Edit</th>
                                <!-- <th>Delete</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($section as $key => $value) { ?>
                                <tr>
                                    <td><a href="moduleList.php?module_id=<?= $value['module_id'] ?>"><?= $value['module_name'] ?></a></td>
                                    <td><a href="pageList.php?section_id=<?= $value['section_id'] ?>"><?= $value['section_name'] ?></a></td>
                                    <td><?= $value['section_description'] ?></td>
                                    <td><a href="addSection.php?edit=true&section_id=<?= $value['section_id'] ?>">Edit</a></td>
                                    <!-- <td><a onclick="deleteSubFeature(<?= $value['m_feature_sub_id'] ?>);" href="javascript:void(0);">Delete</a></td> -->
                                </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                </form>

            </div>
        </div>
        <script type="text/javascript" src="vendor/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="dist/featureSubList.js"></script>
    </body>
</html>