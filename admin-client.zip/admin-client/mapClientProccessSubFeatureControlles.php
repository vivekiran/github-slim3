<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$enable = $_POST['enable'];
$listMapSubControllerID = $_POST['listMapSubControllerID'];

if(!empty($listMapSubControllerID)){
    $explodeListMapSubControllerId = explode(",",$listMapSubControllerID);
}



$client_delete_feature_control = $disclosure_platform->client_feature_control()->where("client_id",$client_id)->where("map_feature_sub_control_id",$explodeListMapSubControllerId);
$map_controll_data_results = array(
    'control_order' => null,
    "deleted_by" => -1,
    "deleted_datentime" => date('Y-m-d H:i:s')
);
$client_delete_feature_control->update($map_controll_data_results);



$countZeroOrder = 1;
foreach ($enable as $key => $value) {
    $map_feature_sub_control_id = null;
    $m_control_id = null;
    $exploadListMapControllIds = null;
    $exploadListMapControllIds = explode("_", $value);
    $map_feature_sub_control_id = $exploadListMapControllIds[0];
    $m_control_id = $exploadListMapControllIds[1];

    if(!empty($map_feature_sub_control_id)){
        $client_feature_control = $disclosure_platform->client_feature_control()->where("client_id",$client_id)->where("map_feature_sub_control_id = ?",$map_feature_sub_control_id);

        if($client_feature_control->count()==0){
                $m_feature = $disclosure_platform->client_feature_control()->insert(array(
                "client_id" => $client_id,
                "map_feature_sub_control_id" => $map_feature_sub_control_id,
                "control_order" => $countZeroOrder,
                "created_by"=> '-1',
                "created_datentime" => date("Y-m-d H:i:s"),
                "activate_by"=> '-1',
                "activated_datentime" => date("Y-m-d H:i:s")
                ));
        } else {
                $data_results = array(
                 "control_order" => $countZeroOrder,
                "deleted_by" => NULL,
                "deleted_datentime" => NULL
            );
            $client_feature_control->update($data_results);
        }
        $countZeroOrder++;
    }

}