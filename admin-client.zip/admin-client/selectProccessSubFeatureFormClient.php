<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$sql = " SELECT mfsc.map_feature_sub_control_id, mf.m_feature_id, mf.feature, mfsb.m_feature_sub_id, mfsb.feature_sub, mc.m_control_id, mc.control_name, if(cfc.client_feature_control_id is not null,'Y','N') enabled_disabled,mc.control_type, if(cfc.control_label is not null,cfc.control_label,mfsc.control_label) control_label,
 if(cfc.control_tooltip is not null,cfc.control_tooltip,mfsc.control_tooltip) control_tooltip,mfsc.description
FROM map_feature_sub mfs
INNER JOIN m_feature mf on mfs.m_feature_id = mf.m_feature_id and mfs.activated_datentime is not null and mfs.deleted_datentime is null
INNER JOIN m_feature_sub mfsb on mfs.m_feature_sub_id = mfsb.m_feature_sub_id and mfsb.activated_datentime is not null and mfsb.deleted_datentime is null
INNER JOIN map_feature_sub_control mfsc on mfs.m_feature_sub_id = mfsc.m_feature_sub_id and mfsc.activated_datentime is not null and mfsc.deleted_datentime is null
INNER JOIN m_control mc on mfsc.m_control_id = mc.m_control_id and mc.activated_datentime is not null and mc.deleted_datentime is null
LEFT JOIN client_feature_control cfc on mfsc.map_feature_sub_control_id = cfc.map_feature_sub_control_id and cfc.client_id = $client_id and cfc.activated_datentime is not null and cfc.deleted_datentime is null
where mc.control_type NOT IN('button') AND mfs.m_feature_id = $selectFeature and mfs.m_feature_sub_id = $selectSubFeature ORDER BY cfc.control_order ASC, mfsc.control_order ASC";


$view_client_control = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);


?>




<!doctype html>
<html>
    <head>
        <title>Select Clients</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>

        <style>
            .ui-state-highlight {
                border: 1px solid #fcefa1;
                background: #fbf9ee;
                color: #363636;
                height: 46px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <h2>Arrange Form Controller to - <?= $view_client_control[0]['feature_sub'] ?></h2>
                <form action="" method="post" role="form" name="validateForm" id="validateForm">
                    <input type="hidden" name="client_id" id="client_id" value="<?= $client_id ?>" />
                    <input type="hidden" name="selectFeature" id="selectFeature" value="<?= $selectFeature ?>" />
                    <input type="hidden" name="selectSubFeature" id="selectSubFeature" value="<?= $selectSubFeature ?>" />
                    <input type="hidden" name="totalCount" id="totalCount" value="<?= count($view_client_control) ?>" />


                    <div class="row">
                        <div class="col-md-8">
                            <ul id="sortable" class="list-group">
                                <?php
                                $listMapSubControllerID = null;
                                foreach ($view_client_control as $key => $value) {
                                    $map_feature_sub_control_id = null;
                                    $map_feature_sub_control_id = $value['map_feature_sub_control_id'];
                                    if (empty($listMapSubControllerID)) {
                                        $listMapSubControllerID.= $map_feature_sub_control_id;
                                    } else {
                                        $listMapSubControllerID.= "," . $map_feature_sub_control_id;
                                    }
                                    ?>

                                    <li class="list-group-item">
                                        <span class="glyphicon glyphicon-move"></span>
                                        <label>
                                            <input type="checkbox" name="enable[]" id="enable_<?= $key ?>" value="<?= $value['map_feature_sub_control_id'] ?>_<?= $value['m_control_id'] ?>" <?php if ($value['enabled_disabled'] == 'Y') { ?> checked="checked" <?php } ?> />
                                            <span class="ui-state-default " ><?= $value['control_label'] ?></span>
                                        </label>
                                        <?php if ($value['enabled_disabled'] == 'Y') { ?>
                                            <a class="btn btn-xs btn-primary btnEdit" val="<?= $value['map_feature_sub_control_id'] ?>">Edit</a>
                                    <?php } ?>

                                    </li>

                                <?php } ?>

                            </ul>
                            <input type="hidden" name="listMapSubControllerID" id="listMapSubControllerID" value="<?= $listMapSubControllerID ?>" />
                        </div>
                    </div>


                    <div class="modal fade" id="edit-controls" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">

                            </div>
                        </div>
                    </div>

                    <div>
                        <input type="submit"  name="proceed" id="proceed" value="Save"  class="btn btn-primary" />
                    </div>

                </form>

            </div>
        </div>

        <script type="text/javascript" src="dist/selectProccessSubFeatureFormClient.js"></script>
    </body>
</html>