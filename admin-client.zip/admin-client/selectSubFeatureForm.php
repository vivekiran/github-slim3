<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


  $sql = "SELECT m_feature_id, feature FROM m_feature WHERE deleted_datentime is NULL";
  $m_feature = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>

    
<!doctype html>
<html>
    <head>
        <title>Form Builder</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
            
    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
                
            <div class="jumbotron">
                <h2>Select Sub Feature for design form</h>
                    <h3>Create Forms</h3>
                    <form name="validateForm" id="validateForm" class="form-horizontal" action="selectProccessSubFeatureForm.php" method="post" role="form">

                        <div class="form-group">
                            <label for="form_name" class="col-sm-2 control-label">Select Feature</label>
                            <div class="col-sm-10">
                                <select required="required" id="selectFeature" class="form-control" name="selectFeature">
                                    <option value="">--Select feature-</option>
                                    <?php foreach ($m_feature as $value) {
                                        ?>
                                        <option value="<?= $value['m_feature_id'] ?>"><?= $value['feature'] ?></option>
                                    <?php } ?>

                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="form_name" class="col-sm-2 control-label">Select Sub Feature</label>
                            <div class="col-sm-10">
                                <select required="required" id="selectSubFeature" class="form-control" name="selectSubFeature">
                                    <option value="">--Select feature-</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>                    
                    </form>

            </div>
        </div>
        <script type="text/javascript" src="dist/selectSubFeatureForm.js"></script>
            
    </body>
</html>