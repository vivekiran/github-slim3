<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if (!empty($section_id)) {
    $sql = "SELECT module_id,section_id, section_name,section_description FROM section ";
    $sql .= "WHERE section_id='$section_id'";
    $section = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

$section_name = $section['section_name'];
$section_description = $section['section_description'];
$module_id = $section['module_id'];
?>




<!doctype html>
<html>
    <head>
        <title>Add Section</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <h2>Add/Update Section</h2>
                <form action="processAddUpdateSection.php" class="form-horizontal" method="post" role="form">
                    <input type="hidden" name="section_id" id="section_id" value="<?php echo $section_id ?>" />

                      <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select module</label>
                     <div class="col-sm-9">
                    <select name="module_id" id="module_id" required="required" class="form-control">
                        <option value="">--Select module--</option>
                        <?php
                        foreach ($disclosure_platform->module() as $module) {
                            $selectedModule = ($module_id==$module['module_id'] ? "selected='selected'":'');
                            if(!empty($fetchModule)){
                                $selectedModule = ($fetchModule==$module['module_id'] ? "selected='selected'":'');
                            }


                      echo '<option '.$selectedModule.' value="'.$module['module_id'].'">'.$module['module_name'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>

                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Section name</label>
                        <div class="col-sm-9">
                            <input required="required" type="text" name="enter_section_name" class="form-control" id="enter_section_name" value="<?php echo $section_name; ?>" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Section Description</label>
                        <div class="col-sm-9">
                            <textarea name="enter_section_description" class="form-control" id="enter_section_description"><?php echo $section_description; ?></textarea>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>


    </body>
</html>