<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$m_feature_sub = $disclosure_platform->m_feature_sub()->where("m_feature_sub_id",$sub_feature_id);
$data = array(
    "deleted_by" => -1,
    "deleted_datentime" => date("Y-m-d H:i:s")
);
$m_feature_sub->update($data);
