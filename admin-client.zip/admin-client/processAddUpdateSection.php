<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


if(empty($section_id)){

    $section = $disclosure_platform->section()->insert(array(
        "section_name" => $enter_section_name,
        "section_description"=> $enter_section_description,
        "module_id" => $module_id
    ));
} else {

    $disclosure_platform->section()->insert_update(array("section_id" => $section_id), array(
        "section_name" => $enter_section_name,
        "section_description"=> $enter_section_description,
        "module_id" => $module_id
    ));
}

header("location:sectionList.php");