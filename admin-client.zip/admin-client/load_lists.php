<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$aColumns = array( 'feature', 'm_feature_id');


$sortColums = $aColumns;

/*
 * Paging
 */
$sLimit = "";
if (isset($_POST['iDisplayStart']) && $_POST['iDisplayLength'] != '-1') {
    $sLimit = "" . intval($_POST['iDisplayStart']) . ", " .
            intval($_POST['iDisplayLength']);
}

/*
 * Ordering
 */
$sOrder = "";
if (isset($_POST['iSortCol_0'])) {
    $sOrder = "ORDER BY  ";
    for ($i = 0; $i < intval($_POST['iSortingCols']); $i++) {
        if ($_POST['bSortable_' . intval($_POST['iSortCol_' . $i])] == "true") {
            $sOrder .= "" . $sortColums[intval($_POST['iSortCol_' . $i])] . " " .
                    ($_POST['sSortDir_' . $i] === 'asc' ? 'asc' : 'desc') . ", ";
        }
    }

    $sOrder = substr_replace($sOrder, "", -2);
    if ($sOrder == "ORDER BY") {
        $sOrder = "";
    }
}
$prm_report_limit = $_POST['limit'];

$sql = 'SELECT m_feature_id, feature FROM m_feature ';

if (!empty($sOrder)) {
    $sql.= $sOrder;
}

if (!empty($prm_report_limit)) {
    $sql.=" LIMIT $prm_report_limit";
}
$outputData = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);


$totalCount = count($outputData);

/*
 * Output
 */
$output = array(
    "sEcho" => intval($_POST['sEcho']),
    "iTotalRecords" => $totalCount,
    "iTotalDisplayRecords" => $totalCount,
    "aaData" => array()
);

foreach ($outputData as $aRow) {
    $row = array();
    for ($i = 0; $i < count($aColumns); $i++) {
        $row[] = $common->correctcase($aRow[$aColumns[$i]]);
    }
    $output['aaData'][] = $row;
}

echo json_encode($output);

?>