<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$sql = 'SELECT f.fieldset_id,p.page_id,f.fieldset_name,mpt.page_type,f.page_type_id,p.page_name
FROM fieldset f
INNER JOIN page p ON f.page_id = p.page_id
LEFT JOIN m_page_type mpt ON f.page_type_id = mpt.page_type_id and mpt.active_yn="Y" ';


if(!empty($fieldset_id))
$sql.= ' WHERE f.fieldset_id='.$fieldset_id;

if(!empty($page_id))
$sql.= ' WHERE f.page_id='.$page_id;


$sql.= ' ORDER BY f.fieldset_id ASC';




$fieldset = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>






<!doctype html>
<html>
    <head>
        <title>Page List</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <!-- Standard button -->

                <h2>Filedset List</h2>
                <div style="float:right;"><a href="addFieldset.php?fetchPage=<?=$page_id?>&fetchFieldSet=<?=$fieldset_id?>" class="btn btn-primary">Add Filedset</a></div>
                <div class="clear-fix"></div>
                <form name="validateForm" id="validateForm" method="POST" action="">
                    <table cellpadding="0" cellspacing="0" border="0" class="table" id="table_feature_list" width="100%">
                        <thead>
                            <tr>
                                <th>Page Name</th>
                                <th>Filedset ID</th>
                                <th>Filedset Name</th>
                                <th>Page Type</th>
                                <th>Edit</th>
                                <!-- <th>Delete</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($fieldset as $key => $value) { ?>
                                <tr>
                                    <td><a href="pageList.php?page_id=<?= $value['page_id'] ?>"><?= $value['page_name'] ?></a></td>
                                    <td><?= $value['fieldset_id'] ?></td>
                                 <td><a href="fieldList.php?fieldset_id=<?= $value['fieldset_id'] ?>"><?= $value['fieldset_name'] ?></a></td>
                                    <td><?= $value['page_type'] ?></td>
                                    <td><a href="addFieldset.php?edit=true&fieldset_id=<?= $value['fieldset_id'] ?>">Edit</a></td>
                                    <!-- <td><a onclick="deleteSubFeature(<?= $value['m_feature_sub_id'] ?>);" href="javascript:void(0);">Delete</a></td> -->
                                </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                </form>

            </div>
        </div>
        <script type="text/javascript" src="vendor/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="dist/featureSubList.js"></script>
    </body>
</html>