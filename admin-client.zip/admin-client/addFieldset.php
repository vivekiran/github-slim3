<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if (!empty($fieldset_id)) {
    $sql = "SELECT f.page_id,f.fieldset_id, f.fieldset_name,mpt.page_type_id FROM fieldset f
    INNER JOIN m_page_type mpt on f.page_type_id=mpt.page_type_id and mpt.active_yn='Y'
    ";
    $sql .= "WHERE fieldset_id='$fieldset_id'";
    $fieldset = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

$fieldset_name = $fieldset['fieldset_name'];
$page_type_id = $fieldset['page_type_id'];
$page_id = $fieldset['page_id'];
?>




<!doctype html>
<html>
    <head>
        <title>Add Fieldset</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <h2>Add/Update Fieldset</h2>
                <form action="processAddUpdateFieldset.php" class="form-horizontal" method="post" role="form">
                    <input type="hidden" name="fieldset_id" id="fieldset_id" value="<?php echo $fieldset_id ?>" />

                <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select page</label>
                     <div class="col-sm-9">
                    <select name="page_id" id="page_id" required="required" class="form-control">
                        <option value="">--Select page--</option>
                        <?php
                        foreach ($disclosure_platform->page() as $page) {
                            $selectedModule = ($page_id==$page['page_id'] ? "selected='selected'":'');

                            if(!empty($fetchPage)){
                                $selectedModule =  ($fetchPage==$page['page_id'] ? "selected='selected'":'');
                            }
                      echo '<option '.$selectedModule.' value="'.$page['page_id'].'">'.$page['page_name'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>


                  <div class="form-group">
                    <label for="form_name" class="col-sm-3 control-label">Select page type</label>
                     <div class="col-sm-9">
                    <select name="page_type_id" id="page_type_id" required="required" class="form-control">
                        <option value="">--Select page type--</option>
                        <?php
                        foreach ($disclosure_platform->m_page_type() as $page) {
                            $selectedTypeModule = ($page_type_id==$page['page_type_id'] ? "selected='selected'":'');
                      echo '<option '.$selectedTypeModule.' value="'.$page['page_type_id'].'">'.$page['page_type'].'</option>';
                        }
                        ?>

                      </select>
                  </div>
                  </div>

                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Fieldset Name</label>
                        <div class="col-sm-9">
                            <input required="required" type="text" name="enter_fieldset_name" class="form-control" id="enter_fieldset_name" value="<?php echo $fieldset_name; ?>" />
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>


    </body>
</html>