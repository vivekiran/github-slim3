<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$fields_query = "SELECT c.m_control_id as control_id,a.control_label as label, c.control_type as field_type, a.description, c.control_name as field_element_name, c.control_name as field_element_id,  c.control_name as cid, a.control_tooltip as tool_tip,a.map_feature_sub_control_id as map_control_id,a.dependent_on as dependent_on
    FROM
    m_control c
    INNER JOIN map_feature_sub_control a ON c.m_control_id = a.m_control_id
    INNER JOIN map_feature_sub mfs ON a.m_feature_sub_id = mfs.m_feature_sub_id
    WHERE
    a.m_feature_sub_id ='" . $selectSubFeature . "' AND mfs.m_feature_id = '" . $selectFeature . "' AND c.control_type NOT IN ('button','html') AND c.deleted_datentime is NULL
    GROUP BY
    c.m_control_id ORDER BY control_order ASC";

$fields = $connection->query($fields_query)->fetchAll(PDO::FETCH_ASSOC);


$totalCount = count($fields);

?>




<!doctype html>
<html>
    <head>
        <title>Controllers and their dependency</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <!-- Standard button -->

                <h2>List Of Controllers and their dependency</h2>

                <div class="clear-fix"></div>
                <form name="validateForm" id="validateForm" method="POST" action="processDependecyControll.php">
            <input type="hidden" name="m_feature_id" id="m_feature_id" value="<?= $selectFeature ?>" />
            <input type="hidden" name="m_feature_sub_id" id="m_feature_sub_id" value="<?= $selectSubFeature ?>" />
                   <input type="hidden" name="totalCount" id="totalCount" value="<?=$totalCount?>" />
                    <table cellpadding="0" cellspacing="0" border="0" class="table"  width="100%">
                        <thead>
                            <tr>
                                <th>Controller name</th>
                                <th>Dependency</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($fields as $key => $value) { ?>
                            <input type="hidden" name="hidden_map_control_id_<?=$key?>" value="<?= $value['map_control_id'] ?>" />
                                <tr>
                                    <td><?= $value['label'] ?></td>
                                    <td>
                                    <select name="selectDepedecy_<?= $value['map_control_id'] ?>">
                                        <option value="">--select dependency--</option>
                                        <?php
                                        foreach ($fields as $keySelect => $valueSelect) { ?>
                                        <option <?php if($valueSelect['field_element_name']==$value['dependent_on']){?> selected="selected" <?php } ?> value="<?=$valueSelect['field_element_name'] ?>"><?= $valueSelect['label'] ?></option>
                                         <?php } ?>
                                        </select>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                    <input type="submit" name="process" id="process" class="btn btn-primary btn-large" value="Update" />
                </form>

            </div>
        </div>
        <script type="text/javascript" src="vendor/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="dist/featureSubList.js"></script>
    </body>
</html>