<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$sql = "SELECT  mfs.m_feature_sub_id,mfb.feature_sub,mfs.map_feature_sub_id
FROM  `client_feature_sub` cfs
INNER JOIN map_feature_sub mfs ON cfs.map_feature_sub_id = mfs.map_feature_sub_id
INNER JOIN m_feature_sub mfb ON mfs.m_feature_sub_id = mfb.m_feature_sub_id
WHERE cfs.client_id =$client_id and mfs.m_feature_id=$m_feature_id  and cfs.deleted_datentime is NULL and mfs.deleted_datentime is NULL and mfb.deleted_datentime is NULL
GROUP BY  mfs.`m_feature_sub_id` ORDER BY cfs.feature_sub_order";


$map_feature_sub  = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);



$selectBox = '<select id="selectSubFeatures" class="multiselect" multiple="multiple" name="selectSubFeatures[]">';

foreach ($map_feature_sub as $sub_feature) {

   $m_feature_sub_id =  $sub_feature['m_feature_sub_id'];

   $map_feature_sub_id = $sub_feature['map_feature_sub_id'];

    if(empty($selected_m_feature_sub_id)){
        $selected_m_feature_sub_id.=$m_feature_sub_id;
    }else{
        $selected_m_feature_sub_id.=",".$m_feature_sub_id;
    }


    if(empty($selected_map_feature_sub_id)){
        $selected_map_feature_sub_id.=$map_feature_sub_id;
    }else{
        $selected_map_feature_sub_id.=",".$map_feature_sub_id;
    }

    $selectBox .= '<option selected="selected" value="' . $map_feature_sub_id . '">' . stripslashes(trim($sub_feature['feature_sub'])) . '</option>';
}

$selectMasterFeatureSub = "SELECT b.map_feature_sub_id,a.m_feature_sub_id,c.feature,a.feature_sub,c.m_feature_id FROM m_feature_sub a INNER JOIN map_feature_sub b on a.m_feature_sub_id = b.m_feature_sub_id inner JOIN m_feature c on b.m_feature_id=c.m_feature_id WHERE c.m_feature_id=$m_feature_id and a.deleted_datentime is NULL and b.deleted_datentime is NULL and c.deleted_datentime is NULL ";

if(!empty($selected_m_feature_sub_id))
$selectMasterFeatureSub.=" and a.m_feature_sub_id NOT IN ($selected_m_feature_sub_id) ";


$selectMasterFeatureSub.=" ORDER BY b.feature_sub_order ASC ";

$map_feature_sub_list  = $connection->query($selectMasterFeatureSub)->fetchAll(PDO::FETCH_ASSOC);



foreach ($map_feature_sub_list as $sub_feature) {

   $map_feature_sub_id =  $sub_feature['map_feature_sub_id'];


    $selectBox .= '<option value="' . $map_feature_sub_id . '">' . stripslashes(trim($sub_feature['feature_sub'])) . '</option>';
}

$selectBox .= '</select>';

echo json_encode(array(
    'objData' => $selectBox,
    'm_feature_id' => $m_feature_id,
    'selected_map_feature_sub_id' => $selected_map_feature_sub_id
));
?>