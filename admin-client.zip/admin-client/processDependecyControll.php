<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

for($i=0; $i < $totalCount; $i++) {

    $map_feature_sub_control_id = null;
    $depedencyValue = null;

    $map_feature_sub_control_id = $_POST['hidden_map_control_id_'.$i];
    $depedencyValue = $_POST['selectDepedecy_'.$map_feature_sub_control_id];

    if(!empty($map_feature_sub_control_id)){

        $map_feature_sub_control = $disclosure_platform->map_feature_sub_control()->where("map_feature_sub_control_id",$map_feature_sub_control_id);
        $data = array(
            "dependent_on" => $depedencyValue
        );
        $map_feature_sub_control->update($data);

    }
}
header("location:selectDependencyProccessSubFeatureForm.php?selectFeature=$m_feature_id&selectSubFeature=$m_feature_sub_id");