<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$m_clients = $disclosure_platform->m_clients("m_client_id",$select_client)->fetch();

$client_name = $m_clients['client_name'];
$client_id = $m_clients['m_client_id'];
?>


<!doctype html>
<html>
<head>
  <title>Form Builder</title>
  <meta name="description" content="">
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
  <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
  <h1>Selected Client - <?=$client_name?></h1>
<div class="row">
 <div class="col-md-12">

  <h3>Create Forms</h3>
  <form action="saveform.php" method="post" role="form">
    <input type="hidden" name="hidden_client_id" id="hidden_client_id" value="<?=$client_id?>" />
  <div class="form-group">
    <label for="form_name">Enter form name</label>
    <input required="required" type="text" class="form-control" id="form_name" name="form_name" placeholder="Enter form name">
  </div>
  <div class="form-group">
    <label for="form_description">Enter form description(Optional)</label>
    <textarea class="form-control" id="form_description" name="form_description" placeholder="Enter form description"></textarea>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
</div>
</div>
</div>


</body>
</html>