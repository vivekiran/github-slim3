<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

?>




<!doctype html>
<html>
<head>
  <title>Select Clients</title>
  <meta name="description" content="">
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
  <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
      <?php require_once 'menu.php'; ?>
<div class="row">
 <div class="col-md-12">
  <h1>Create Forms</h1>
  <form action="mapClientFeature.php" method="post" role="form">
  <div class="form-group">
    <label for="form_name">Select Client</label>
    <select name="select_client" id="select_client" required="required" class="form-control">
        <option selected="selected" value="">--Select Client--</option>
        <?php
        foreach ($disclosure_platform->client() as $client) {
          echo '<option value="'.$client['client_id'].'">'.$client['client_name'].'</option>';
        }
        ?>

      </select>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
</div>
</div>
</div>


</body>
</html>