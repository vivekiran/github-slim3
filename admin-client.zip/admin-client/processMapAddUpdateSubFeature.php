<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$m_feature_id = trim($_POST['selectFeature']);
$selectSubFeatures = $_POST['selectSubFeatures'];



$map_feature_sub = $disclosure_platform->map_feature_sub()->where("m_feature_id",$m_feature_id)->where("deleted_datentime",null);



if($map_feature_sub->count()==0){

    $countZeroOrder = 1;
    foreach ($selectSubFeatures as $key => $value) {
            $m_feature = $disclosure_platform->map_feature_sub()->insert(array(
            "m_feature_id" => $m_feature_id,
            "m_feature_sub_id" => $value,
            "feature_sub_order" => $countZeroOrder,
            "created_by"=> '-1',
            "created_datentime" => date("Y-m-d H:i:s"),
            "activate_by"=> '-1',
            "activated_datentime" => date("Y-m-d H:i:s")
        ));
        $countZeroOrder++;
    }
} else{
    $data = array(
        "feature_sub_order" => NULL,
        "deleted_by" => -1,
        "deleted_datentime" => date("Y-m-d H:i:s")
    );
    $map_feature_sub->update($data);
    $countZeroOrder = 1;
    foreach ($selectSubFeatures as $key => $value) {
        $map_feature_sub_results = $disclosure_platform->map_feature_sub()->where("m_feature_id",$m_feature_id)->where("m_feature_sub_id",$value);


        if($map_feature_sub_results->count()==0){
                $m_feature = $disclosure_platform->map_feature_sub()->insert(array(
                "m_feature_id" => $m_feature_id,
                "m_feature_sub_id" => $value,
                "created_by"=> '-1',
                "feature_sub_order" => $countZeroOrder,
                "created_datentime" => date("Y-m-d H:i:s"),
                "activate_by"=> '-1',
                "activated_datentime" => date("Y-m-d H:i:s")
            ));
        } else {
                $data_results = array(
                 "feature_sub_order" => $countZeroOrder,
                "deleted_by" => NULL,
                "deleted_datentime" => NULL
            );
            $map_feature_sub_results->update($data_results);
        }
        $countZeroOrder++;
    }
}


header("location:mapFeatureSubFeature.php");