<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$sql = 'SELECT f.field_group,f.field_id,fs.fieldset_id,fs.fieldset_name,f.field_label,he.element_name,f.html_element_id,fa.attribute_value as field_name
FROM field f
INNER JOIN fieldset fs ON f.fieldset_id = fs.fieldset_id
LEFT JOIN field_attribute  fa ON f.field_id = fa.field_id and fa.attribute_name = "name"
LEFT JOIN html_element he ON f.html_element_id = he.html_element_id ';


if(!empty($fieldset_id))
$sql.= ' WHERE fs.fieldset_id='.$fieldset_id;

if(!empty($page_id))
$sql.= ' WHERE f.page_id='.$page_id;

$sql.= ' ORDER BY f.field_id ASC';


$field = $connection->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>






<!doctype html>
<html>
    <head>
        <title>Field List</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <!-- Standard button -->

                <h2>Field List</h2>
                <div style="float:right;"><a href="addField.php?fetchPage=<?=$page_id?>&fetchFieldSet=<?=$fieldset_id?>"  class="btn btn-primary">Add Field</a></div>
                <div class="clear-fix"></div>
                <br /><br /><br />
                <form name="validateForm" id="validateForm" method="POST" action="">
                    <table cellpadding="0" cellspacing="0" border="0" class="table" id="table_feature_list" width="100%">
                        <thead>
                            <tr>
                                <th>Fieldset Name</th>
                                <th>Field Id</th>
                                <th>Field Group</th>
                                <th>Field Name</th>
                                <th>Field Label</th>
                                <th>Field Type</th>
                                <th>Edit</th>
                                <th>Properties</th>
                                <!-- <th>Delete</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($field as $key => $value) { ?>
                                <tr>
                                   <td><a href="fieldsetList.php?fieldset_id=<?= $value['fieldset_id'] ?>"><?= $value['fieldset_name'] ?></a></td>
                                   <td><?= $value['field_id'] ?></td>
                                   <td><?= $value['field_group'] ?></td>
                                    <td><?= $value['field_name'] ?></td>
                                    <td><?= $value['field_label'] ?></td>
                                    <td><?= $value['element_name'] ?></td>
                                    <td><a href="addField.php?edit=true&field_id=<?= $value['field_id'] ?>">Edit</a>
                                    </td>
                                    <td><a element_id="<?= $value['html_element_id'] ?>" class="btn btn-xs btn-primary btnEdit" val="<?= $value['field_id'] ?>">Properties</a></td>
                                    <!-- <td><a onclick="deleteSubFeature(<?= $value['m_feature_sub_id'] ?>);" href="javascript:void(0);">Delete</a></td> -->
                                </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                                        <div class="modal fade" id="edit-controls" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">

                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
        <script type="text/javascript" src="vendor/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="dist/featureSubList.js"></script>
        <script type="text/javascript" src="dist/addField.js"></script>
    </body>
</html>