<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if(empty($page_id)){

    $page = $disclosure_platform->page()->insert(array(
        "page_name" => $enter_page_name,
        "file_name"=> $enter_file_name,
        "section_id" => $section_id
    ));
} else {

    $disclosure_platform->page()->insert_update(array("page_id" => $page_id), array(
        "page_name" => $enter_page_name,
        "file_name"=> $enter_file_name,
        "section_id" => $section_id
    ));
}

header("location:pageList.php");