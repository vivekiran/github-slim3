<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$finalResult = null;

$finalResult = 'Default Value: <input type="checkbox" name="default_selected_option_value[]" size="4" value="" /> Option Value: <input type="text" name="selected_option_value[]" size="4" /> Option Label: <input type="text" name="selected_option_label[]" /> <input onclick="addRow(this.form);" type="button" value="Add row" />';

if(!empty($field_id) && $html_element_id==4){

$field_option_value = $disclosure_platform->field_option_value("field_id",$field_id)->fetch();

$loopSelectOptions = json_decode($field_option_value['option_value'],true);

$default_value = json_decode($field_option_value['default_value'],true);



$counter = 0;
foreach ($loopSelectOptions as $key => $value) {

    $checked = null;

    if (in_array($key, $default_value)) {
          $checked = 'checked';
    }


   $finalResult.= "<br />";
    $finalResult.= '<div  id="rowDynamicNum'.$counter.'">Default Value: <input '.$checked.' type="checkbox" name="default_selected_option_value[]" value="'.$key.'" size="4" />Option Value: <input type="text" name="selected_option_value[]" size="4" value="'.$key.'"> Option Label: <input type="text" name="selected_option_label[]" value="'.$value.'"> <input type="button" value="Remove" onclick="removeDynamicRow('.$counter.');"></p>';

    $counter++;
}

}

echo $finalResult;
?>