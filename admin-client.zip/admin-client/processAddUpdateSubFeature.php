<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

if(empty($m_feature_sub_id)){

    $m_feature_sub = $disclosure_platform->m_feature_sub()->insert(array(
        "feature_sub" => $enter_sub_feature_name,
        "landing_page" => $landing_page,
        "action_page" => $action_page,
        "created_by"=> '-1',
        "created_datentime" => date("Y-m-d H:i:s"),
        "activated_by"=> '-1',
        "activated_datentime" => date("Y-m-d H:i:s")
    ));
} else {

    $m_feature_sub = $disclosure_platform->m_feature_sub()->where("m_feature_sub_id",$m_feature_sub_id);
    $data = array(
        "feature_sub" => $enter_sub_feature_name,
        "landing_page" => $landing_page,
        "action_page" => $action_page
    );
    $m_feature_sub->update($data);
}

header("location:subFeatureList.php");