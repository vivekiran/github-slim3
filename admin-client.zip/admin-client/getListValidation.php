<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$m_validation = $disclosure_platform->m_validation()->fetchAll();


echo json_encode($m_validation);