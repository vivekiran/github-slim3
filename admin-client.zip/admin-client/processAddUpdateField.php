<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


$add_attribute = $_POST['add_attribute'];

$add_attribute_value = $_POST['add_attribute_value'];

$selected_option_value = $_POST['selected_option_value'];

$selected_option_label = $_POST['selected_option_label'];

$default_selected_option_value = $_POST['default_selected_option_value'];

$list_validation = $_POST['list_validation'];

$validationmessage = $_POST['validationmessage'];

$validationparam = $_POST['validationparam'];

$validationorder = $_POST['validationorder'];


$selctOptionValueArray = array();
foreach ($selected_option_value as $key => $value) {
    if(!empty($value))
    $selctOptionValueArray[$value] = $selected_option_label[$key];
}

$selctOptionDefaultValueArray = array();

foreach ($default_selected_option_value as $key => $value) {
    $selctOptionDefaultValueArray[$key] = $value;
}

if($_SERVER['REMOTE_ADDR']=='192.168.100.43'){



}


if(empty($field_id)){

    $field = $disclosure_platform->field()->insert(array(
        "field_label" => $enter_field_label,
        "fieldset_id" => $fieldset_id,
        "prepend_text" => $enter_prepend_text,
        "html_element_id"=>$html_element_id
    ));

    $field_id = $disclosure_platform->field()->insert_id();

    foreach ($add_attribute as $key => $value) {
            $field_attribute = $disclosure_platform->field_attribute()->insert(array(
                "field_id" => $field_id,
                "attribute_name" => $value,
                "attribute_value"=>($add_attribute_value[$value]=='' ? NULL :$add_attribute_value[$value])
            ));
    }

    // foreach ($list_validation as $key => $value) {
    //         $field_attribute = $disclosure_platform->field_validation()->insert(array(
    //             "field_id" => $field_id,
    //             "validation_id" => $value
    //         ));
    // }
    //
    foreach ($list_validation as $key => $value) {

             $field_validation = $disclosure_platform->field_validation()->insert(array(
                "field_id" => $field_id,
                "validation_id" => $value,
                "param"=>($validationparam[$value]=='' ? NULL :stripslashes($validationparam[$value])),
                "validation_message"=>($validationmessage[$value]=='' ? NULL :$validationmessage[$value]),
                "validation_order"=>($validationorder[$value]=='' ? NULL :$validationorder[$value])
            ));

    }

    if($html_element_id==4){
        $field_option_value = $disclosure_platform->field_option_value()->insert(array(
            "field_id" => $field_id,
            "default_value"=>json_encode($selctOptionDefaultValueArray),
            "option_value"=>json_encode($selctOptionValueArray)
        ));
    }



} else {



    $disclosure_platform->field()->insert_update(array("field_id" => $field_id), array(
        "field_label" => $enter_field_label,
        "fieldset_id" => $fieldset_id,
        "prepend_text" => $enter_prepend_text,
        "html_element_id"=>$html_element_id
    ));

    $field_attribute_result = $disclosure_platform->field_attribute()->where("field_id",$field_id);
    $data = array(
        "attribute_value" => NULL
    );
    $field_attribute_result->update($data);

    foreach ($add_attribute as $key => $value) {

        $field_attribute_count = $disclosure_platform->field_attribute(array("field_id" => $field_id,"attribute_name"=>$value));

        if($field_attribute_count->count()==0){
            $field_attribute = $disclosure_platform->field_attribute()->insert(array(
                "field_id" => $field_id,
                "attribute_name" => $value,
                "attribute_value"=>($add_attribute_value[$value]=='' ? NULL :$add_attribute_value[$value])
            ));

        } else {
            $field_attribute_count->update(array(
                "field_id" => $field_id,
                "attribute_name" => $value,
                "attribute_value"=>($add_attribute_value[$value]=='' ? NULL :$add_attribute_value[$value])
            ));
        }

    }

    $field_validation_update_date = $disclosure_platform->field_validation()->where("field_id",$field_id);
    $dataUpdate = array(
        "deleted_at" => date('Y-m-d H:i:s')
    );
    $field_validation_update_date->update($dataUpdate);

    foreach ($list_validation as $key => $value) {

        $field_validation_count = $disclosure_platform->field_validation(array("field_id" => $field_id,"validation_id"=>$value));

        if($field_validation_count->count()==0){
            $field_validation = $disclosure_platform->field_validation()->insert(array(
                "field_id" => $field_id,
                "validation_id" => $value,
                "param"=>($validationparam[$value]=='' ? NULL :stripslashes($validationparam[$value])),
                "validation_message"=>($validationmessage[$value]=='' ? NULL :$validationmessage[$value]),
                "validation_order"=>($validationorder[$value]=='' ? NULL :$validationorder[$value])
            ));

        } else {
            $field_validation_count->update(array(
                "field_id" => $field_id,
                "validation_id" => $value,
                "param"=>($validationparam[$value]=='' ? NULL :stripslashes($validationparam[$value])),
                "validation_message"=>($validationmessage[$value]=='' ? NULL :$validationmessage[$value]),
                "validation_order"=>($validationorder[$value]=='' ? NULL :$validationorder[$value]),
                "deleted_at"=>NULL
            ));
        }

    }

    if($html_element_id==4){
        $field_option_value_result = $disclosure_platform->field_option_value()->where("field_id",$field_id);
        $data = array(
            "default_value"=>json_encode($selctOptionDefaultValueArray),
            "option_value"=>json_encode($selctOptionValueArray)
        );
        $field_option_value_result->update($data);
    }


}

header("location:fieldList.php");