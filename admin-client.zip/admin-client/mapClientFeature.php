<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


?>




<!doctype html>
<html>
    <head>
        <title>Map Feature Sub feature</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
        <link type="text/css" rel="stylesheet" href="dist/ui.multiselect.css" />
        <link type="text/css" rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/ui-lightness/jquery-ui.css" />

        <style type="text/css">

          /* multiselect styles */
          .multiselect {
            width: 460px;
            height: 200px!important;
          }
          .ui-multiselect div.available{
            float:left!important;
          }
          .ui-multiselect div.selected{
            float:right!important;
          }

        </style>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
                <div class="jumbotron">

                <h2>Map Feature</h2>
                <form  name="validateForm" id="validateForm" class="form-horizontal" action="processClientMapAddUpdateFeature.php" method="POST" role="form">
                    <input type="hidden" name="select_client" id="select_client" value="<?= $select_client ?>" />
                    <input type="hidden" name="list_of_feature_selected" id="list_of_feature_selected" value="" />

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Features</label>
                        <div id="contentDisplay" class="col-sm-10">
                            <select id="selectFeatures" class="multiselect" multiple="multiple" name="selectFeatures[]"></select>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" value="Submit" id="proceed" class="btn btn-primary" name="proceed">
                        </div>
                    </div>

                </form>

            </div>
        </div>

        <script type="text/javascript" src="dist/ui.multiselect.js" ></script>
        <script type="text/javascript" src="dist/mapClientFeature.js"></script>
    </body>
</html>