<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}


if(empty($module_id)){

    $module = $disclosure_platform->module()->insert(array(
        "module_name" => $enter_module_name,
        "description"=> $enter_module_description,
        "service_type" => $service_type
    ));
} else {

    $disclosure_platform->module()->insert_update(array("module_id" => $module_id), array(
        "module_name" => $enter_module_name,
        "description"=> $enter_module_description,
        "service_type" => $service_type
    ));
}

header("location:moduleList.php");