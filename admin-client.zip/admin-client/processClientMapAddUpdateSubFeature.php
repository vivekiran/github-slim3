<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}

$client_id = trim($_POST['select_client']);
$selectSubFeatures = $_POST['selectSubFeatures'];
$list_of_subfeature_selected = $_POST['list_of_subfeature_selected'];

if(!empty($list_of_subfeature_selected)){
    $explode_list_of_subfeature_selected = explode(",",$list_of_subfeature_selected);
}


$client_feature_sub = $disclosure_platform->client_feature_sub()->where("client_id",$client_id)->where("map_feature_sub_id",$explode_list_of_subfeature_selected);

if($client_feature_sub->count()==0){

    $countZeroOrder = 1;
    foreach ($selectSubFeatures as $key => $value) {
            $m_feature = $disclosure_platform->client_feature_sub()->insert(array(
            "client_id" => $client_id,
            "map_feature_sub_id" => $value,
            "feature_sub_order" => $countZeroOrder,
            "created_by"=> '-1',
            "created_datentime" => date("Y-m-d H:i:s"),
            "activate_by"=> '-1',
            "activated_datentime" => date("Y-m-d H:i:s")
        ));
        $countZeroOrder++;
    }
} else{
    $data = array(
        "feature_sub_order" => NULL,
        "deleted_by" => -1,
        "deleted_datentime" => date("Y-m-d H:i:s")
    );
    $client_feature_sub->update($data);
    $countZeroOrder = 1;
    foreach ($selectSubFeatures as $key => $value) {
        $client_feature_sub_results = $disclosure_platform->client_feature_sub()->where("client_id",$client_id)->where("map_feature_sub_id",$value);


        if($client_feature_sub_results->count()==0){
                $m_feature = $disclosure_platform->client_feature_sub()->insert(array(
                "client_id" => $client_id,
                "map_feature_sub_id" => $value,
                "created_by"=> '-1',
                "feature_sub_order" => $countZeroOrder,
                "created_datentime" => date("Y-m-d H:i:s"),
                "activate_by"=> '-1',
                "activated_datentime" => date("Y-m-d H:i:s")
            ));
        } else {
                $data_results = array(
                 "feature_sub_order" => $countZeroOrder,
                "deleted_by" => NULL,
                "deleted_datentime" => NULL
            );
            $client_feature_sub_results->update($data_results);
        }
        $countZeroOrder++;
    }
}


header("location:mapClientFeatureSubFeature.php?select_client=$client_id");