<?php
include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}



if (!empty($m_feature_sub_id)) {
    $sql = "SELECT m_feature_sub_id, feature_sub,landing_page,action_page FROM m_feature_sub ";
    $sql .= "WHERE m_feature_sub_id='$m_feature_sub_id'";
    $m_feature_sub = $connection->query($sql)->fetch(PDO::FETCH_ASSOC);
}

$feature_sub = $m_feature_sub['feature_sub'];
$landing_page = $m_feature_sub['landing_page'];
$action_page = $m_feature_sub['action_page'];
?>




<!doctype html>
<html>
    <head>
        <title>Add Sub Feature</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div class="container">
            <?php require_once 'menu.php'; ?>
            <div class="jumbotron">

                <h2>Add/Update Sub Feature</h2>
                <form action="processAddUpdateSubFeature.php" class="form-horizontal" method="post" role="form">
                    <input type="hidden" name="m_feature_sub_id" id="m_feature_sub_id" value="<?php echo $m_feature_sub_id ?>" />
                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Sub Feature name</label>
                        <div class="col-sm-9">                            
                            <input required="required" type="text" name="enter_sub_feature_name" class="form-control" id="enter_sub_feature_name" value="<?php echo $feature_sub; ?>" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Sub Feature Landing page</label>
                        <div class="col-sm-9">
                            <input required="required" type="text" name="landing_page" class="form-control" id="landing_page" value="<?php echo $landing_page; ?>" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="form_name" class="col-sm-3 control-label">Enter Sub Feature action page</label>
                        <div class="col-sm-9">
                            <input required="required" type="text" name="action_page" class="form-control" id="action_page" value="<?php echo $action_page; ?>" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>


    </body>
</html>