<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);
}
$form_response = stripslashes($form_response);
$form_response = json_decode($form_response,true);

$form_response_final = json_encode($form_response->fields);

$disclosure_platform->debug = true;

$disclosure_platform->m_form_fields(array("m_form_id"=>$form_id,"m_client_id"=>$clientid))->delete();

foreach ($form_response->fields as $field_key => $field_value) {

    $field_label = null;
    $field_type = null;
    $required = null;
    $field_name = null;

    echo "<pre>";
    print_r($field_value);
    echo "</pre>";


    $field_label = $field_value->label;
    $field_type = $field_value->field_type;
    $required = $field_value->required;
    $field_name = $field_value->cid;

    $disclosure_platform->m_form_fields()->insert_update(array("m_form_id" => $form_id,"m_client_id"=>$clientid, "field_name" => $field_name), array("field_type" => $field_type, "field_name" => $field_name, "field_label" => $field_label, "validations" => "", "error_messages" => ""));
}
//$m_forms = $disclosure_platform->m_forms(array("m_form_id" => $form_id,"m_client_id"=>$clientid));
//$m_forms->update(array("form_response" => $form_response_final));

/*
$disclosure_platform->m_form_fields()->insert_update(
    array("m_form_id" => $form_id), // unique key
    array("form_response" => stripslashes($form_response_final)) // insert values if the row doesn't exist
);*/