<?php

include_once dirname(__FILE__) . "/includes.php";

foreach ($_REQUEST as $key => $val) {
    ${$key} = trim($val);

}

$m_validation = $disclosure_platform->m_validation()->select("validation_name,validation_alias")->where("validation_name LIKE ?", "$term%")->fetchAll(PDO::FETCH_ASSOC);


$result = array();
foreach ($m_validation['data'] as $key=>$validation_name) {


    if (strpos(strtolower($validation_name['validation_name']), $term) !== false) {
        array_push($result, array("id"=>$value, "label"=>$validation_name['validation_name'], "value" => strip_tags($validation_name['validation_name'])));
    }
    if (count($result) > 11)
        break;
}

echo json_encode($result);

?>