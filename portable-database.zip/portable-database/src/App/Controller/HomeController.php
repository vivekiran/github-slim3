<?php
namespace ProtablConnector\Controller;

use Psr\Log\LoggerInterface;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use ProtablConnector\Model\User;

class HomeAction
{
    private $view;
    private $logger;
    private $hash;
    private $auth;
    private $session;
    private $jsonRequest;
    public function __construct(JsonRequest $jsonRequest,Twig $view, LoggerInterface $logger, $hash,$auth)
    {
        $this->view     = $view;
        $this->logger   = $logger;
        $this->hash     = $hash;
        $this->auth     = $auth;
        $this->session  = new \App\Helper\Session;
        $this->jsonRequest  = new JsonRequest();
        $this->JsonRender   = new JsonRenderer();

    }
    public function dispatch(Request $request, Response $response, $args)
    {
        $this->logger->info("Home page action dispatched");

        $this->view->render($response, 'home.twig',[
            'user' => User::all(),

            ]);
        return $response;
    }
}
