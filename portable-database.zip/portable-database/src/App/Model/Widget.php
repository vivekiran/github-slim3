<?php
namespace ProtablConnector\Model;

use Illuminate\Database\Eloquent\Model;

class Widget extends Model
{

}
