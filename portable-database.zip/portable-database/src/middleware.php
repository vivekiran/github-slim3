<?php
// Application middleware

// e.g: $app->add(new \Slim\Csrf\Guard);

$auth_middle_ware = function ($request, $response, $next) {

	$user_details = $this->session->get('user_details');

	if($user_details){
		 $response = $next($request, $response);
		 return $response;
	}
	return $response = $response->withRedirect('/?err=3');

};