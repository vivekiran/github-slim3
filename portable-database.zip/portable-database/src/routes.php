<?php
// Routes
//https://github.com/mrcoco/slim3-eloquent-skeleton

$app->get('/', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    $error = trim($request->getParam('err'));
    // Render index view
    //
    $user_details = $this->session->get('user_details');

    if($user_details){
       return $response->withRedirect('/server-details');
    }
    return $this->renderer->render($response, 'index.phtml', compact('error'));
});

$app->post('/auth/login', function ($request, $response) {
    // Sample log message
    $this->logger->info("Majaor error");

    $username = trim($request->getParam('username'));
    $password = trim($request->getParam('password'));

    $environment_details = $this->get('environment');


    if(!empty($username) && !empty($password)){

      $user_details = $this->database->get("users","*",['username'=>$username]);

      if($user_details){
        if (password_verify($password, $user_details['password'])) {

           $this->session->set('user_details', $user_details);

           $this->session->set('logged_in_username',$username);

           $this->database->insert("user_access_log", [
                  "user_id"=>$user_details['id'],
                  "username" => $username,
                  "last_attempt_at" => date('Y-m-d H:i:s'),
                  "hostname" => $environment_details['SERVER_NAME'],
                  'ip_address'=>$environment_details['REMOTE_ADDR'],
                  'browser_agent'=>$environment_details['HTTP_USER_AGENT'],
                  'referring_url'=>$environment_details['HTTP_REFERER'],
                  'comments'=>'Successfull login',
                  'login_success'=>'Y'
            ]);
           return $response->withRedirect('/server-details');
        } else {
              $this->database->insert("user_access_log", [
                  "user_id"=>$user_details['id'],
                  "username" => $username,
                  "password" => $password,
                  "last_attempt_at" => date('Y-m-d H:i:s'),
                  "hostname" => $environment_details['SERVER_NAME'],
                  'ip_address'=>$environment_details['REMOTE_ADDR'],
                  'browser_agent'=>$environment_details['HTTP_USER_AGENT'],
                  'referring_url'=>$environment_details['HTTP_REFERER'],
                  'comments'=>'Invalid password',
                  'login_success'=>'N'
            ]);
        }

        return $response->withRedirect('/?err=1');

      }

      $this->database->insert("user_access_log", [
          "username" => $username,
          "password" => $password,
          "last_attempt_at" => date('Y-m-d H:i:s'),
          "hostname" => $environment_details['SERVER_NAME'],
          'ip_address'=>$environment_details['REMOTE_ADDR'],
          'browser_agent'=>$environment_details['HTTP_USER_AGENT'],
          'referring_url'=>$environment_details['HTTP_REFERER'],
          'comments'=>'Invalid details',
          'login_success'=>'N'
      ]);
    }

   return $response->withRedirect('/?err=1');
});

$app->get('/bcrypt', function ($request, $response, $args) {
    // Sample log message
    return password_hash('test',PASSWORD_DEFAULT);
});


$app->get('/server-details', function ($request, $response) {
    // Sample log message
    $this->logger->info("Welecome to Server Details");
    $server_details=$this->database->select("mysql_servers", "*");

    $logged_in_username = $this->session->get('logged_in_username',null);

    // Render index view
    return $this->renderer->render($response, 'server-details.phtml',compact('server_details','logged_in_username'));
})->add($auth_middle_ware);


$app->get('/connect/{mysql_server_id}/{mysql_server_type}', function ($request, $response) {
    // Sample log message
    $this->logger->info("Welecome to Admin Page");

    $routes = $request->getAttribute('route');
    $mysql_server_id = $routes->getArgument('mysql_server_id');
    $mysql_server_type = $routes->getArgument('mysql_server_type');
    $password = trim($request->getParam('password'));

    $mysql_servers = $this->database->get("mysql_servers", ["hostname","username","database_name","port"], [
                    "id" => $mysql_server_id
                ]);

    $admin_connector = array();
    $admin_connector['database_type'] = 'mysql';
    $admin_connector['server'] = $mysql_servers['hostname'];
    $admin_connector['database_name'] = $mysql_servers['database_name'];
    $admin_connector['username'] = $mysql_servers['username'];
    $admin_connector['password'] = base64_decode($password);
    $admin_connector['port'] = $mysql_servers['port'];
    $admin_connector['charset'] = 'utf8';
    $admin_connector['prefix'] = '';

    $platform_database_details = new medoo($admin_connector);

    switch ($mysql_server_type) {
        case 'PLATFORM':
            $database_details = $platform_database_details->query("select c.client_id as client_id,cc.db_host as db_host,cc.db_user as db_user,cc.db_password as db_password,cc.db_name as db_name,cc.db_port as db_port,c.client_name as client_name from client c
            INNER JOIN client_configuration cc ON c.client_id = cc.client_id AND cc.central_db_id is NOT NULL
            INNER JOIN client_status cs ON c.client_id=cs.client_id and cs.activated_date IS NOT NULL order by c.client_id ASC")->fetchAll(PDO::FETCH_CLASS);
            break;
        default:
            # code...
            break;
    }
    $logged_in_username = $this->session->get('logged_in_username',null);

    return $this->renderer->render($response, 'admin-databases.phtml',compact('database_details','logged_in_username','mysql_server_id','mysql_server_type'));
})->add($auth_middle_ware);

$app->post('/process-query', function ($request, $response) {
    // Sample log message
    $this->logger->info("Process Query");

    $client_details = $request->getParam('client_details');
    $txt_query = trim($request->getParam('txt_query'));

    $mysql_server_id = $request->getParam('mysql_server_id');
    $mysql_server_type = $request->getParam('mysql_server_type');

    $final_result = array();

    if(!empty($txt_query)){

    foreach ($client_details as $client_detail) {
          if(!empty($client_detail)){
            $connection_details = array();
            $sql_data = null;
            $individual_client_connection = null;
            $exploded_connection_details = explode('||',$client_detail);

            $connection_details['database_type'] = 'mysql';
            $connection_details['server'] = $exploded_connection_details[1];
            $connection_details['database_name'] = $exploded_connection_details[4];
            $connection_details['username'] = $exploded_connection_details[2];
            $connection_details['password'] = $exploded_connection_details[3];
            $connection_details['port'] = $exploded_connection_details[5];
            $connection_details['charset'] = 'utf8';
            $connection_details['prefix'] = '';

            $individual_client_connection = new medoo($connection_details);

            // works regardless of statements emulation

            $individual_client_connection->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $individual_client_connection->pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

            $individual_client_connection->pdo->beginTransaction();
            $error_message = null;
            $query_details = preg_split('/[.+;][\s]*\n/', $txt_query, -1, PREG_SPLIT_NO_EMPTY);
            $final_result['error'] = false;
            try{
                //foreach ($query_details as $query_detail) {
                      $stmt = $individual_client_connection->pdo->prepare($txt_query);
                      if (!$stmt->execute()) {

                      }
                //}
               $individual_client_connection->pdo->commit();
               $final_result['error_message'][] = null;
            }catch(Exception $e){
                //An exception has occured, which means that one of our database queries
                //failed.
                //Print out the error message.
                $error_message = $exploded_connection_details[6]. " (".$exploded_connection_details[4].")=>".$e->getMessage();
                $final_result['error_message'][] = $error_message;
                 $final_result['error'] = true;
                //Rollback the transaction.
                $individual_client_connection->pdo->rollBack();
            }

            /*foreach ($query_details as $query_detail) {
              $sth.= $individual_client_connection->pdo->prepare($query_detail);
            }

            if (!$sth->execute()) {
                $final_result[$exploded_connection_details[6]]['error'] = true;


                $individual_client_connection->pdo->rollBack();
           } else {

                $individual_client_connection->pdo->commit();
                $final_result[$exploded_connection_details[6]]['error'] = false;
           }

            $final_result[$exploded_connection_details[6]]['info'] = $individual_client_connection->info();
            $final_result[$exploded_connection_details[6]]['last_query'] = $sth->queryString;
            $final_result[$exploded_connection_details[6]]['error_info'] = $sth->errorInfo();
           $final_result[$exploded_connection_details[6]]['data'] = $sth->fetchAll(PDO::FETCH_ASSOC);*/
           $user_details = $this->session->get('user_details');

           $this->database->insert("mysql_logs", [
                  "mysql_server_id"=>$mysql_server_id,
                  "mysql_server_type"=>$mysql_server_type,
                  "client_id"=>$exploded_connection_details[0],
                  "created_by"=>$user_details['id'],
                  "created_at" => date('Y-m-d H:i:s'),
                  "sql_log" => json_encode(array('info'=>$individual_client_connection->info(),'last_query'=>$individual_client_connection->last_query(),"error_info"=>$individual_client_connection->error(),"query"=>$txt_query,"error_message"=>$error_message)),
            ]);

          }
    }

  }


   return json_encode($final_result);
   die();

})->add($auth_middle_ware);


// Define app routes
$app->get('/jsonresponse', function ($request, $response,$args) {
    $data = array('name' => 'Rob', 'age' => 40);
    return $response->withJson($data, 500);
});

// Define app routes
$app->get('/logout', function ($request, $response,$args) {
    $this->session->destroy();
    return $response->withRedirect('/?err=2');
});