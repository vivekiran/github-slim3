<?php
return [
    'settings' => [
        'displayErrorDetails' => true, // set to false in production

        // Renderer settings
        'renderer' => [
            'template_path' => __DIR__ . '/../templates/',
        ],

        // Monolog settings
        'logger' => [
            'name' => 'slim-app',
            'path' => __DIR__ . '/../logs/app.log',
        ],
        // Slim Settings
        'db' => [
            'database_type' => 'mysql',
            'server' => getenv('DB_HOST'),
            'database_name' => getenv('DB_NAME'),
            'username' => getenv('DB_USER'),
            'password' => getenv('DB_PASSWORD'),
            'port'=> getenv('DB_PORT'),
            'charset'   => 'utf8',
            'prefix'    => '',
        ]
    ],
];
