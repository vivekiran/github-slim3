<?php

require_once __DIR__.'/../app/config/config.php';


class TestPlayer extends PHPUnit_Framework_TestCase
{

    private $conn = null;

    public function getConnection() {
        if ($this->conn === null) {
            try {
                $options = array(PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ, PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING);

                 $this->conn = new PDO(DB_TYPE . ':host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET, DB_USER, DB_PASS,$options);


            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
        return $this->conn;
    }


    public function testTeamsEquals()
    {
        $this->getConnection();

        $array1 = array(0=>array('identifier'=>'1','name'=>'Team One','logoUri'=>'http://localhost:9000/img/logo'),1=>array('identifier'=>'2','name'=>'Team two','logoUri'=>'http://localhost:9000/img/logo'));
        $array2 = $this->getAllTeams();

        $this->assertEquals($array1,$array2);
    }

    public function testTeamsNotEquals()
    {
        $this->getConnection();

        $array1 = array(0=>array('identifier'=>'1','name'=>'Team Oe','logoUri'=>'http://localhost:9000/img/logo'),1=>array('identifier'=>'2','name'=>'Team two','logoUri'=>'http://localhost:9000/img/logo'));
        $array2 = $this->getAllTeams();

        $this->assertNotEquals($array1,$array2);
    }

    public function getAllTeams()
    {
        $selectAllTeams = "SELECT identifier, name, logoUri FROM teams";

        $resultAllTeams = $this->conn->prepare($selectAllTeams);
        $resultAllTeams->execute();

        return $resultAllTeams->fetchAll(PDO::FETCH_ASSOC);

    }

    // ...
}