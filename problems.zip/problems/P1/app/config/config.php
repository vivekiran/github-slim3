<?php

if (ENVIRONMENT == 'development' || ENVIRONMENT == 'dev') {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

define('PUBLIC_FOLDER', 'public');
define('URL', 'http://localhost/problems/P1/public/');

/**
 * Configuration for: Database
 * This is the place where you define your database credentials, database type etc.
 */
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'problem_one');
define('DB_USER', 'root');
define('DB_PASS', 'root@123#');
define('DB_CHARSET', 'utf8');