<div class="container">
    <h2>List Of All teams</h2>
        	<ol>
    		<?php
    		foreach ($teams as $team):
    		?>
    		<li><a href="<?php echo URL; ?>team/getteamplayres/<?php echo $team->identifier;?>"><?php echo $team->name;?></a>
    			<img src="<?php echo URL; ?>img/<?php echo $team->logoUri;?>" alt="<?php echo $team->name;?>" />
    		<?php
    		endforeach
		    ?>
    	</ol>

</div>
