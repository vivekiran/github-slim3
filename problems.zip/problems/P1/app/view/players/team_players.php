<div class="container">
    <h2>Team Name : <?php echo $team->name; ?></h2>

    <ol>
            <?php
            foreach ($team_players as $team_player):
            ?>
            <li><?php echo $team_player->firstName." ".$team_player->lastName;?></a>
            <?php
            endforeach
            ?>
        </ol>

</div>

