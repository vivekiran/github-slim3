<div class="container">
    <h2>All Players </h2>

    <ol>
            <?php
            foreach ($players as $player):
            ?>
            <li><?php echo $player->firstName." ".$player->lastName;?></a>
            <?php
            endforeach
            ?>
        </ol>

</div>

