<?php

class Player extends Controller
{

    public function index(){

        $players = $this->model->getAllPlayers();

        require APP . 'view/_templates/header.php';
        require APP . 'view/players/index.php';
        require APP . 'view/_templates/footer.php';

    }
}
