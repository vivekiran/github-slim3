<?php

class Home extends Controller
{

    public function index()
    {
        // load views
        // getting all songs and amount of songs
        $teams = $this->model->getAllTeams();

        require APP . 'view/_templates/header.php';
        require APP . 'view/home/index.php';
        require APP . 'view/_templates/footer.php';
    }
}
