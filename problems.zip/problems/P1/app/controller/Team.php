<?php

class Team extends Controller
{

    public function getIndex(){

    }

    public function getteamplayres($team_id)
    {

        if(is_null($team_id)){
            header('location: ' . URL . 'error');
        }
        // if we have an id of a song that should be deleted
        if (isset($team_id)) {
            // do deleteSong() in model/model.php
           $team_players =  $this->model->getTeamPlayers($team_id);

           $team =  $this->model->getTeam($team_id);
        }

        require APP . 'view/_templates/header.php';
        require APP . 'view/players/team_players.php';
        require APP . 'view/_templates/footer.php';
    }
}
