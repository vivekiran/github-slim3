<?php

class Model
{

    function __construct($db)
    {
        try {
            $this->db = $db;
        } catch (PDOException $e) {
            exit('Database connection could not be established.');
        }
    }

    /**
     * Get all teams from database
     */
    public function getAllTeams()
    {
        $selectAllTeams = "SELECT identifier, name, logoUri FROM teams";

        $resultAllTeams = $this->db->prepare($selectAllTeams);
        $resultAllTeams->execute();

        return $resultAllTeams->fetchAll();

    }


    public function getTeamPlayers($team_id)
    {

        $selectAllTeamPlayers = "SELECT p.identifier, p.firstName,p.lastName,imageUri,tp.team_id FROM team_players tp INNER JOIN players p on p.identifier = tp.team_id WHERE tp.team_id=:team_id";

        $resultAllTeams = $this->db->prepare($selectAllTeamPlayers);

        $parameters = array(':team_id' => $team_id);

        $resultAllTeams->execute($parameters);

        return $resultAllTeams->fetchAll();
    }

    public function getTeam($team_id){

        $selectTeam = "SELECT name from teams where identifier=:team_id";

        $resultTeam = $this->db->prepare($selectTeam);

        $parameters = array(':team_id' => $team_id);

        $resultTeam->execute($parameters);

        return $resultTeam->fetch();
    }

    public function getAllPlayers(){

        $selectAllPlayers = "SELECT identifier, firstName, lastName FROM players";

        $resultAllPlayers = $this->db->prepare($selectAllPlayers);
        $resultAllPlayers->execute();

        return $resultAllPlayers->fetchAll();
    }
}
